package com.example.floatkeys

import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable

object Style {
    val base = intArrayOf(0xFF2B3440.toInt(), 0xFF1F3A5F.toInt(), 0xFF3B2A5C.toInt(), 0xFF1F4D3A.toInt(), 0xFF5C2A44.toInt())
    val acc = intArrayOf(0xFF4C8DFF.toInt(), 0xFF38BDF8.toInt(), 0xFFA78BFA.toInt(), 0xFF34D399.toInt(), 0xFFF472B6.toInt())

    fun theme(p: SharedPreferences) = p.getInt("theme", 0).coerceIn(0, base.lastIndex)
    fun a(c: Int, f: Float) = (c and 0xFFFFFF) or ((f.coerceIn(0f, 1f) * 255).toInt() shl 24)

    /** Fundo de uma tecla (cor do tema, opacidade e arredondamento vêm das preferências). */
    fun key(p: SharedPreferences, d: Float, c: Int? = null, sel: Boolean = false) = GradientDrawable().apply {
        val al = p.getInt("kalpha", 85) / 100f
        cornerRadius = p.getInt("kround", 10) * d
        setColor(a(c ?: base[theme(p)], al))
        if (sel) setStroke((3 * d).toInt(), 0xFFF9A825.toInt())
        else setStroke(maxOf(1, d.toInt()), a(0xFFFFFFFF.toInt(), .22f * al))
    }
}
