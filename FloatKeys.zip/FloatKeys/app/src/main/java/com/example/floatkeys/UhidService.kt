package com.example.floatkeys

import android.content.Context
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Roda no processo shell (Shizuku UserService): cria dispositivos HID reais em /dev/uhid. */
class UhidService() : IUhid.Stub() {
    constructor(c: Context) : this()

    private var kb: FileOutputStream? = null
    private var mo: FileOutputStream? = null
    private var gp: FileOutputStream? = null

    private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

    // teclado padrão: modificadores + 6 teclas
    private val kbDesc = bytes(
        0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
        0x95, 0x01, 0x75, 0x08, 0x81, 0x01, 0x95, 0x05, 0x75, 0x01, 0x05, 0x08, 0x19, 0x01, 0x29, 0x05, 0x91, 0x02, 0x95, 0x01, 0x75, 0x03, 0x91, 0x01,
        0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00, 0xC0)

    // mouse padrão: 3 botões + X/Y relativos + roda (relatório de 4 bytes)
    private val moDesc = bytes(
        0x05, 0x01, 0x09, 0x02, 0xA1, 0x01, 0x09, 0x01, 0xA1, 0x00, 0x05, 0x09, 0x19, 0x01, 0x29, 0x03, 0x15, 0x00, 0x25, 0x01,
        0x95, 0x03, 0x75, 0x01, 0x81, 0x02, 0x95, 0x01, 0x75, 0x05, 0x81, 0x03, 0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38,
        0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x03, 0x81, 0x06, 0xC0, 0xC0)

    // gamepad: 16 botões, X/Y, Z/Rz e hat (relatório de 7 bytes)
    private val gpDesc = bytes(
        0x05, 0x01, 0x09, 0x05, 0xA1, 0x01,
        0x05, 0x09, 0x19, 0x01, 0x29, 0x10, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x10, 0x81, 0x02,
        0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x32, 0x09, 0x35, 0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x04, 0x81, 0x02,
        0x09, 0x39, 0x15, 0x00, 0x25, 0x07, 0x35, 0x00, 0x46, 0x3B, 0x01, 0x65, 0x14, 0x75, 0x04, 0x95, 0x01, 0x81, 0x42,
        0x75, 0x04, 0x95, 0x01, 0x81, 0x03, 0xC0)

    /** bus: 3 = USB, 5 = Bluetooth, 6 = virtual */
    private fun create(name: String, desc: ByteArray, bus: Int, vid: Int, pid: Int, phys: String, uniq: String): FileOutputStream {
        val o = FileOutputStream("/dev/uhid")
        val b = ByteBuffer.allocate(280 + desc.size).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(11)                                              // UHID_CREATE2
        b.put(name.toByteArray())
        b.position(4 + 128); b.put(phys.toByteArray())
        b.position(4 + 128 + 64); b.put(uniq.toByteArray())
        b.position(4 + 128 + 64 + 64)
        b.putShort(desc.size.toShort()); b.putShort(bus.toShort())
        b.putInt(vid); b.putInt(pid); b.putInt(0x0110); b.putInt(0)  // vendor, product, version, country
        b.put(desc)
        o.write(b.array())
        return o
    }

    private fun input(o: FileOutputStream?, data: ByteArray) {
        try {
            val b = ByteBuffer.allocate(6 + data.size).order(ByteOrder.LITTLE_ENDIAN)
            b.putInt(12); b.putShort(data.size.toShort()); b.put(data)  // UHID_INPUT2
            o?.write(b.array())
        } catch (e: Throwable) { }
    }

    override fun destroy() {
        try { kb?.close(); mo?.close(); gp?.close() } catch (e: Exception) { }
        System.exit(0)
    }

    override fun start(bus: Int): Boolean = try {
        if (kb == null) kb = if (bus == 3) create("Logitech USB Keyboard", kbDesc, 3, 0x046D, 0xC31C, "usb-xhci-hcd.0-1/input0", "")
        else create("Bluetooth Keyboard", kbDesc, 5, 0x046D, 0xB342, "a4:c1:38:5e:20:11", "d8:3a:dd:41:07:9c")
        true
    } catch (e: Throwable) { false }

    override fun startMouse(bus: Int): Boolean = try {
        if (mo == null) mo = if (bus == 3) create("Logitech USB Optical Mouse", moDesc, 3, 0x046D, 0xC077, "usb-xhci-hcd.0-2/input0", "")
        else create("Bluetooth Mouse", moDesc, 5, 0x046D, 0xB02A, "a4:c1:38:5e:20:11", "d8:3a:dd:77:19:2b")
        true
    } catch (e: Throwable) { false }

    override fun startPad(): Boolean = try {
        if (gp == null) gp = create("FloatKeys Gamepad", gpDesc, 6, 0x18D1, 2, "", "")
        true
    } catch (e: Throwable) { false }

    override fun report(data: ByteArray) = input(kb, data)
    override fun mouse(data: ByteArray) = input(mo, data)
    override fun pad(data: ByteArray) = input(gp, data)
}
