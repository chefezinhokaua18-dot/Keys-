package com.example.floatkeys

import android.content.Context
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Roda no processo shell (Shizuku UserService): cria um teclado HID REAL em /dev/uhid. */
class UhidService() : IUhid.Stub() {
    constructor(c: Context) : this()

    private var out: FileOutputStream? = null

    // descritor padrão de teclado HID (boot keyboard): modificadores + 6 teclas simultâneas
    private val desc = intArrayOf(
        0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
        0x95, 0x01, 0x75, 0x08, 0x81, 0x01, 0x95, 0x05, 0x75, 0x01, 0x05, 0x08, 0x19, 0x01, 0x29, 0x05, 0x91, 0x02, 0x95, 0x01, 0x75, 0x03, 0x91, 0x01,
        0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00, 0xC0
    ).map { it.toByte() }.toByteArray()

    override fun destroy() {
        try { out?.close() } catch (e: Exception) { }
        System.exit(0)
    }

    override fun start(): Boolean = try {
        if (out == null) {
            out = FileOutputStream("/dev/uhid")
            val b = ByteBuffer.allocate(280 + desc.size).order(ByteOrder.LITTLE_ENDIAN)
            b.putInt(11)                                              // UHID_CREATE2
            b.put("FloatKeys Keyboard".toByteArray())
            b.position(4 + 128 + 64 + 64)                             // name, phys, uniq
            b.putShort(desc.size.toShort()); b.putShort(6.toShort())  // rd_size, bus = BUS_VIRTUAL
            b.putInt(0x18D1); b.putInt(1); b.putInt(0); b.putInt(0)   // vendor, product, version, country
            b.put(desc)
            out!!.write(b.array())
        }
        true
    } catch (e: Throwable) { false }

    override fun report(data: ByteArray) {
        try {
            val b = ByteBuffer.allocate(6 + data.size).order(ByteOrder.LITTLE_ENDIAN)
            b.putInt(12); b.putShort(data.size.toShort()); b.put(data)  // UHID_INPUT2
            out?.write(b.array())
        } catch (e: Throwable) { }
    }
}
