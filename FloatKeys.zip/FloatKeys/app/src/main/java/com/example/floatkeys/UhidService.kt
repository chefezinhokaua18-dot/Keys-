package com.example.floatkeys

import android.content.Context
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Roda no processo shell (Shizuku UserService): cria dispositivos HID reais em /dev/uhid (teclado e gamepad). */
class UhidService() : IUhid.Stub() {
    constructor(c: Context) : this()

    private var kb: FileOutputStream? = null
    private var gp: FileOutputStream? = null

    private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

    // teclado padrão (boot keyboard): modificadores + 6 teclas
    private val kbDesc = bytes(
        0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
        0x95, 0x01, 0x75, 0x08, 0x81, 0x01, 0x95, 0x05, 0x75, 0x01, 0x05, 0x08, 0x19, 0x01, 0x29, 0x05, 0x91, 0x02, 0x95, 0x01, 0x75, 0x03, 0x91, 0x01,
        0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00, 0xC0)

    // gamepad: 16 botões, eixos X/Y (analógico esq), Z/Rz (analógico dir) e hat (D-pad) = relatório de 7 bytes
    private val gpDesc = bytes(
        0x05, 0x01, 0x09, 0x05, 0xA1, 0x01,
        0x05, 0x09, 0x19, 0x01, 0x29, 0x10, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x10, 0x81, 0x02,
        0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x32, 0x09, 0x35, 0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x04, 0x81, 0x02,
        0x09, 0x39, 0x15, 0x00, 0x25, 0x07, 0x35, 0x00, 0x46, 0x3B, 0x01, 0x65, 0x14, 0x75, 0x04, 0x95, 0x01, 0x81, 0x42,
        0x75, 0x04, 0x95, 0x01, 0x81, 0x03, 0xC0)

    private fun create(name: String, desc: ByteArray, pid: Int): FileOutputStream {
        val o = FileOutputStream("/dev/uhid")
        val b = ByteBuffer.allocate(280 + desc.size).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(11)                                              // UHID_CREATE2
        b.put(name.toByteArray())
        b.position(4 + 128 + 64 + 64)                             // name, phys, uniq
        b.putShort(desc.size.toShort()); b.putShort(6.toShort())  // rd_size, bus = BUS_VIRTUAL
        b.putInt(0x18D1); b.putInt(pid); b.putInt(0); b.putInt(0) // vendor, product, version, country
        b.put(desc)
        o.write(b.array())
        return o
    }

    private fun input(o: FileOutputStream?, data: ByteArray) {
        try {
            val b = ByteBuffer.allocate(6 + data.size).order(ByteOrder.LITTLE_ENDIAN)
            b.putInt(12); b.putShort(data.size.toShort()); b.put(data)  // UHID_INPUT2
            o?.write(b.array())
        } catch (e: Throwable) { }
    }

    override fun destroy() {
        try { kb?.close(); gp?.close() } catch (e: Exception) { }
        System.exit(0)
    }

    override fun start(): Boolean = try { if (kb == null) kb = create("FloatKeys Keyboard", kbDesc, 1); true } catch (e: Throwable) { false }
    override fun report(data: ByteArray) = input(kb, data)
    override fun startPad(): Boolean = try { if (gp == null) gp = create("FloatKeys Gamepad", gpDesc, 2); true } catch (e: Throwable) { false }
    override fun pad(data: ByteArray) = input(gp, data)
}
