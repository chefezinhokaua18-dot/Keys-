package com.example.floatkeys

import android.content.Context
import android.graphics.*
import android.widget.TextView

/** Desenha o analógico estilo StarDesk: círculo escuro translúcido, letras W A S D e bolinha clara com anel azul. */
fun drawJoy(cv: Canvas, p: Paint, cx: Float, cy: Float, r: Float, kx: Float, ky: Float) {
    p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER
    p.style = Paint.Style.FILL; p.color = 0x73111827
    cv.drawCircle(cx, cy, r - r * .02f, p)
    p.style = Paint.Style.STROKE; p.strokeWidth = r * .03f; p.color = 0xCCFFFFFF.toInt()
    cv.drawCircle(cx, cy, r - r * .03f, p)
    p.style = Paint.Style.FILL; p.color = 0xE6FFFFFF.toInt(); p.textSize = r * .2f
    val ty = p.textSize * .35f
    cv.drawText("W", cx, cy - r * .8f + ty, p); cv.drawText("S", cx, cy + r * .8f + ty, p)
    cv.drawText("A", cx - r * .8f, cy + ty, p); cv.drawText("D", cx + r * .8f, cy + ty, p)
    val kr = r * .3f; val px = cx + kx * r * .55f; val py = cy + ky * r * .55f
    p.color = 0xFFD6D9E0.toInt()
    cv.drawCircle(px, py, kr, p)
    p.style = Paint.Style.STROKE; p.strokeWidth = kr * .24f; p.color = 0xFF3B82F6.toInt()
    cv.drawCircle(px, py, kr + p.strokeWidth / 2f, p)
}

class JoyView(c: Context) : TextView(c) {
    var kx = 0f; var ky = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) = drawJoy(cv, p, width / 2f, height / 2f, minOf(width, height) / 2f, kx, ky)
}

/** Zona de movimento (metade esquerda): o analógico aparece onde o dedo encosta, como no Free Fire. */
class ZoneView(c: Context) : View(c) {
    var on = false; var cx = 0f; var cy = 0f; var kx = 0f; var ky = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) { if (on) drawJoy(cv, p, cx, cy, 62 * resources.displayMetrics.density, kx, ky) }
}

/** Botão de tiro arrastável: círculo com mira; a mira acompanha o dedo e fica vermelha enquanto atira. */
class FireView(c: Context) : TextView(c) {
    var kx = 0f; var ky = 0f; var down = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = minOf(w, h) / 2f; val cx = w / 2f; val cy = h / 2f
        p.style = Paint.Style.FILL; p.color = if (down) 0x99DC2626.toInt() else 0x73111827
        cv.drawCircle(cx, cy, r * .97f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * .05f; p.color = if (down) 0xFFFCA5A5.toInt() else 0xCCFFFFFF.toInt()
        cv.drawCircle(cx, cy, r * .95f, p)
        val px = cx + kx * r * .35f; val py = cy + ky * r * .35f
        p.strokeWidth = r * .07f; p.color = Color.WHITE
        cv.drawCircle(px, py, r * .3f, p)
        cv.drawLine(px, py - r * .38f, px, py - r * .55f, p); cv.drawLine(px, py + r * .38f, px, py + r * .55f, p)
        cv.drawLine(px - r * .38f, py, px - r * .55f, py, p); cv.drawLine(px + r * .38f, py, px + r * .55f, py, p)
        p.style = Paint.Style.FILL; cv.drawCircle(px, py, r * .06f, p)
    }
}

/** Ícone de mouse como no StarDesk: corpo branco, botão clicado em azul. 1006/1007 = rolagem (pílula vertical com seta azul). */
class MouseView(c: Context, private val code: Int) : TextView(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2f; val cy = h / 2f
        val blue = 0xFF3B8CF0.toInt(); val gray = 0xFFB8BEC9.toInt()
        p.style = Paint.Style.FILL
        if (code == 1006 || code == 1007) {
            val s = minOf(w, h) * .7f; val pw = s * .46f; val q = pw * .26f
            p.color = 0xFFF1F3F6.toInt()
            cv.drawRoundRect(RectF(cx - pw / 2f, cy - s / 2f, cx + pw / 2f, cy + s / 2f), pw / 2f, pw / 2f, p)
            fun tri(y: Float, upward: Boolean, col: Int) {
                val dir = if (upward) -1f else 1f
                path.reset(); path.moveTo(cx, y + dir * q); path.lineTo(cx - q, y - dir * q); path.lineTo(cx + q, y - dir * q); path.close()
                p.color = col; cv.drawPath(path, p)
            }
            tri(cy - s * .2f, true, if (code == 1006) blue else gray); tri(cy + s * .2f, false, if (code == 1006) gray else blue)
            return
        }
        val s = minOf(w, h) * .68f; val bw = s * .64f
        val l = cx - bw / 2f; val r = cx + bw / 2f; val t = cy - s / 2f; val b = cy + s / 2f; val rr = bw / 2f
        val body = RectF(l, t, r, b); val split = t + s * .44f
        p.color = 0xFFF1F3F6.toInt()
        cv.drawRoundRect(body, rr, rr, p)
        cv.save(); path.reset(); path.addRoundRect(body, rr, rr, Path.Direction.CW); cv.clipPath(path)
        p.color = blue
        if (code == 1003) cv.drawRect(l, t, cx, split, p)
        if (code == 1004) cv.drawRect(cx, t, r, split, p)
        cv.restore()
        p.style = Paint.Style.STROKE; p.strokeWidth = s * .04f; p.color = 0xFF4B5563.toInt()
        cv.drawLine(l, split, r, split, p); cv.drawLine(cx, t, cx, split, p)
        val ww = bw * .17f; val wh = s * .22f
        p.style = Paint.Style.FILL; p.color = if (code == 1005) blue else gray
        cv.drawRoundRect(RectF(cx - ww / 2f, t + s * .08f, cx + ww / 2f, t + s * .08f + wh), ww / 2f, ww / 2f, p)
    }
}
