package com.example.floatkeys

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.MotionEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

/** Injeta teclas no sistema inteiro via IInputManager (executado como shell pelo Shizuku). */
object Inj {
    private var im: Any? = null
    private var m: java.lang.reflect.Method? = null
    private var dev = KeyCharacterMap.VIRTUAL_KEYBOARD
    private val downs = HashMap<Int, Long>()

    /** game=true: tenta usar o ID de um dispositivo de teclado real (alguns jogos ignoram o teclado virtual). */
    fun configure(game: Boolean) {
        dev = KeyCharacterMap.VIRTUAL_KEYBOARD
        hid(game)
        if (!game) return
        for (id in InputDevice.getDeviceIds()) {
            val x = InputDevice.getDevice(id) ?: continue
            if (!x.isVirtual && (x.sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD) { dev = id; break }
        }
    }

    // ---- teclado HID real (UHID via Shizuku UserService): o Android passa a ver um teclado físico ----
    private var uhid: IUhid? = null
    @Volatile private var hidOn = false
    private var bound = false
    private val pressed = LinkedHashSet<Int>()
    private var mods = 0
    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName("com.example.floatkeys", UhidService::class.java.name))
            .daemon(false).processNameSuffix("uhid").debuggable(false).version(1)
    }
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            uhid = IUhid.Stub.asInterface(b)
            hidOn = try { uhid!!.start() } catch (e: Throwable) { false }
        }
        override fun onServiceDisconnected(n: ComponentName?) { uhid = null; hidOn = false }
    }
    private val usage = HashMap<Int, Int>().apply {
        for (c in 0..25) put(KeyEvent.KEYCODE_A + c, 4 + c)
        for (n in 1..9) put(KeyEvent.KEYCODE_0 + n, 0x1D + n)
        put(KeyEvent.KEYCODE_0, 0x27)
        for (i in 0..11) put(KeyEvent.KEYCODE_F1 + i, 0x3A + i)
        putAll(mapOf(KeyEvent.KEYCODE_ENTER to 0x28, KeyEvent.KEYCODE_ESCAPE to 0x29, KeyEvent.KEYCODE_DEL to 0x2A,
            KeyEvent.KEYCODE_TAB to 0x2B, KeyEvent.KEYCODE_SPACE to 0x2C, KeyEvent.KEYCODE_CAPS_LOCK to 0x39,
            KeyEvent.KEYCODE_INSERT to 0x49, KeyEvent.KEYCODE_MOVE_HOME to 0x4A, KeyEvent.KEYCODE_PAGE_UP to 0x4B,
            KeyEvent.KEYCODE_FORWARD_DEL to 0x4C, KeyEvent.KEYCODE_MOVE_END to 0x4D, KeyEvent.KEYCODE_PAGE_DOWN to 0x4E,
            KeyEvent.KEYCODE_DPAD_RIGHT to 0x4F, KeyEvent.KEYCODE_DPAD_LEFT to 0x50, KeyEvent.KEYCODE_DPAD_DOWN to 0x51,
            KeyEvent.KEYCODE_DPAD_UP to 0x52))
    }
    private val modBit = mapOf(KeyEvent.KEYCODE_CTRL_LEFT to 1, KeyEvent.KEYCODE_SHIFT_LEFT to 2,
        KeyEvent.KEYCODE_ALT_LEFT to 4, KeyEvent.KEYCODE_META_LEFT to 8)

    fun hid(enable: Boolean) {
        try {
            if (enable && !bound && ready()) { bound = true; Shizuku.bindUserService(args, conn) }
            else if (!enable && bound) { Shizuku.unbindUserService(args, conn, true); bound = false; uhid = null; hidOn = false; pressed.clear(); mods = 0 }
        } catch (e: Throwable) { Log.e("Inj", "uhid", e); bound = false }
    }

    private fun hidSend(code: Int, down: Boolean): Boolean {
        val mb = modBit[code]
        if (mb != null) mods = if (down) mods or mb else mods and mb.inv()
        else { val u = usage[code] ?: return false; if (down) pressed.add(u) else pressed.remove(u) }
        val r = ByteArray(8); r[0] = mods.toByte()
        pressed.take(6).forEachIndexed { i, u -> r[2 + i] = u.toByte() }
        return try { uhid?.report(r); uhid != null } catch (e: Throwable) { hidOn = false; false }
    }

    fun ready() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun ensure() {
            if (m == null) {
                HiddenApiBypass.addHiddenApiExemptions("")
                val b = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
                im = Class.forName("android.hardware.input.IInputManager\$Stub")
                    .getMethod("asInterface", IBinder::class.java).invoke(null, b)
                m = im!!.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.java)
            }
    }

    /** Injeta qualquer evento (tecla ou toque) como shell via Shizuku. */
    fun inject(e: InputEvent) { try { ensure(); m!!.invoke(im, e, 0) } catch (t: Throwable) { Log.e("Inj", "inject", t) } }

    fun send(code: Int, down: Boolean, meta: Int) {
        if (hidOn && hidSend(code, down)) return
        try {
            ensure()
            val t = SystemClock.uptimeMillis()
            val t0 = if (down) { downs[code] = t; t } else (downs.remove(code) ?: t)
            val e = KeyEvent(t0, t, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0, meta,
                dev, Keys.scan(code), 0, InputDevice.SOURCE_KEYBOARD)
            m!!.invoke(im, e, 0) // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
        } catch (t: Throwable) { Log.e("Inj", "falha ao injetar tecla", t) }
    }
}

object Keys {
    val map: Map<String, Int> = linkedMapOf<String, Int>().apply {
        put("ESC", KeyEvent.KEYCODE_ESCAPE); put("TAB", KeyEvent.KEYCODE_TAB); put("CAPS", KeyEvent.KEYCODE_CAPS_LOCK)
        put("SHIFT", KeyEvent.KEYCODE_SHIFT_LEFT); put("CTRL", KeyEvent.KEYCODE_CTRL_LEFT); put("ALT", KeyEvent.KEYCODE_ALT_LEFT)
        put("WIN", KeyEvent.KEYCODE_META_LEFT); put("ENTER", KeyEvent.KEYCODE_ENTER); put("SPACE", KeyEvent.KEYCODE_SPACE)
        put("BKSP", KeyEvent.KEYCODE_DEL); put("DEL", KeyEvent.KEYCODE_FORWARD_DEL); put("INS", KeyEvent.KEYCODE_INSERT)
        put("HOME", KeyEvent.KEYCODE_MOVE_HOME); put("END", KeyEvent.KEYCODE_MOVE_END)
        put("PGUP", KeyEvent.KEYCODE_PAGE_UP); put("PGDN", KeyEvent.KEYCODE_PAGE_DOWN)
        put("UP", KeyEvent.KEYCODE_DPAD_UP); put("DOWN", KeyEvent.KEYCODE_DPAD_DOWN)
        put("LEFT", KeyEvent.KEYCODE_DPAD_LEFT); put("RIGHT", KeyEvent.KEYCODE_DPAD_RIGHT)
        for (i in 1..12) put("F$i", KeyEvent.KEYCODE_F1 + i - 1)
        for (c in 'A'..'Z') put("$c", KeyEvent.KEYCODE_A + (c - 'A'))
        for (n in 0..9) put("$n", KeyEvent.KEYCODE_0 + n)
    }

    // códigos de scan (Linux) — alguns jogos/emuladores leem o scancode em vez do keycode
    private val sc = HashMap<Int, Int>().apply {
        "QWERTYUIOP".forEachIndexed { i, c -> put(KeyEvent.KEYCODE_A + (c - 'A'), 16 + i) }
        "ASDFGHJKL".forEachIndexed { i, c -> put(KeyEvent.KEYCODE_A + (c - 'A'), 30 + i) }
        "ZXCVBNM".forEachIndexed { i, c -> put(KeyEvent.KEYCODE_A + (c - 'A'), 44 + i) }
        for (n in 1..9) put(KeyEvent.KEYCODE_0 + n, 1 + n)
        put(KeyEvent.KEYCODE_0, 11)
        for (i in 0..9) put(KeyEvent.KEYCODE_F1 + i, 59 + i)
        put(KeyEvent.KEYCODE_F11, 87); put(KeyEvent.KEYCODE_F12, 88)
        putAll(mapOf(KeyEvent.KEYCODE_ESCAPE to 1, KeyEvent.KEYCODE_TAB to 15, KeyEvent.KEYCODE_CAPS_LOCK to 58,
            KeyEvent.KEYCODE_SHIFT_LEFT to 42, KeyEvent.KEYCODE_CTRL_LEFT to 29, KeyEvent.KEYCODE_ALT_LEFT to 56,
            KeyEvent.KEYCODE_META_LEFT to 125, KeyEvent.KEYCODE_ENTER to 28, KeyEvent.KEYCODE_SPACE to 57,
            KeyEvent.KEYCODE_DEL to 14, KeyEvent.KEYCODE_FORWARD_DEL to 111, KeyEvent.KEYCODE_INSERT to 110,
            KeyEvent.KEYCODE_MOVE_HOME to 102, KeyEvent.KEYCODE_MOVE_END to 107, KeyEvent.KEYCODE_PAGE_UP to 104,
            KeyEvent.KEYCODE_PAGE_DOWN to 109, KeyEvent.KEYCODE_DPAD_UP to 103, KeyEvent.KEYCODE_DPAD_DOWN to 108,
            KeyEvent.KEYCODE_DPAD_LEFT to 105, KeyEvent.KEYCODE_DPAD_RIGHT to 106))
    }
    fun scan(c: Int) = sc[c] ?: 0

    fun meta(c: Int) = when (c) {
        KeyEvent.KEYCODE_SHIFT_LEFT -> KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        KeyEvent.KEYCODE_CTRL_LEFT -> KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        KeyEvent.KEYCODE_ALT_LEFT -> KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        KeyEvent.KEYCODE_META_LEFT -> KeyEvent.META_META_ON or KeyEvent.META_META_LEFT_ON
        KeyEvent.KEYCODE_CAPS_LOCK -> KeyEvent.META_CAPS_LOCK_ON
        else -> 0
    }
}

/** Toques simulados (multitoque): joystick e botões de tela, para jogos que não leem teclado. */
object Touch {
    private val p = LinkedHashMap<Int, FloatArray>()
    private var t0 = 0L
    fun active(id: Int) = p.containsKey(id)

    private fun go(action: Int, idx: Int) {
        val n = p.size
        val pp = Array(n) { MotionEvent.PointerProperties() }
        val pc = Array(n) { MotionEvent.PointerCoords() }
        p.entries.forEachIndexed { i, e ->
            pp[i].id = e.key; pp[i].toolType = MotionEvent.TOOL_TYPE_FINGER
            pc[i].x = e.value[0]; pc[i].y = e.value[1]; pc[i].pressure = 1f; pc[i].size = 1f
        }
        val a = if (action == MotionEvent.ACTION_POINTER_DOWN || action == MotionEvent.ACTION_POINTER_UP)
            action or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT) else action
        Inj.inject(MotionEvent.obtain(t0, SystemClock.uptimeMillis(), a, n, pp, pc, 0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0))
    }

    fun down(id: Int, x: Float, y: Float) {
        if (p.containsKey(id)) return
        val first = p.isEmpty(); if (first) t0 = SystemClock.uptimeMillis()
        p[id] = floatArrayOf(x, y)
        go(if (first) MotionEvent.ACTION_DOWN else MotionEvent.ACTION_POINTER_DOWN, p.keys.indexOf(id))
    }

    fun move(id: Int, x: Float, y: Float) { val v = p[id] ?: return; v[0] = x; v[1] = y; go(MotionEvent.ACTION_MOVE, 0) }

    fun up(id: Int) {
        if (!p.containsKey(id)) return
        go(if (p.size == 1) MotionEvent.ACTION_UP else MotionEvent.ACTION_POINTER_UP, p.keys.indexOf(id))
        p.remove(id)
    }

    fun clear() { p.keys.toList().forEach { up(it) } }
}
