package com.example.floatkeys

import android.app.Instrumentation
import android.content.pm.PackageManager
import android.os.SystemClock
import android.view.KeyEvent
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

object Inj {
    private val executor = Executors.newSingleThreadExecutor()
    private val instrumentation by lazy { Instrumentation() }

    fun ready(): Boolean {
        return try {
            Shizuku.pingBinder() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }
    }

    fun sendKeyState(keyCode: Int, isDown: Boolean) {
        executor.execute {
            try {
                val now = SystemClock.uptimeMillis()
                val action = if (isDown) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP
                val event = KeyEvent(now, now, action, keyCode, 0)
                instrumentation.sendKeySync(event)
            } catch (_: SecurityException) {
            } catch (_: Exception) {
            }
        }
    }

    fun tapKey(keyCode: Int) {
        sendKeyState(keyCode, true)
        executor.execute {
            SystemClock.sleep(45)
            sendKeyState(keyCode, false)
        }
    }
}
