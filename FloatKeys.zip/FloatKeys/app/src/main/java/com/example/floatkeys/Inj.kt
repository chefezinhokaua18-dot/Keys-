package com.example.floatkeys

import android.content.pm.PackageManager
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

/** Injeta teclas no sistema inteiro via IInputManager (executado como shell pelo Shizuku). */
object Inj {
    private var im: Any? = null
    private var m: java.lang.reflect.Method? = null
    private var dev = KeyCharacterMap.VIRTUAL_KEYBOARD
    private val downs = HashMap<Int, Long>()

    /** game=true: tenta usar o ID de um dispositivo de teclado real (alguns jogos ignoram o teclado virtual). */
    fun configure(game: Boolean) {
        dev = KeyCharacterMap.VIRTUAL_KEYBOARD
        if (!game) return
        for (id in InputDevice.getDeviceIds()) {
            val x = InputDevice.getDevice(id) ?: continue
            if (!x.isVirtual && (x.sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD) { dev = id; break }
        }
    }

    fun ready() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun send(code: Int, down: Boolean, meta: Int) {
        try {
            if (m == null) {
                HiddenApiBypass.addHiddenApiExemptions("")
                val b = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
                im = Class.forName("android.hardware.input.IInputManager\$Stub")
                    .getMethod("asInterface", IBinder::class.java).invoke(null, b)
                m = im!!.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.java)
            }
            val t = SystemClock.uptimeMillis()
            val t0 = if (down) { downs[code] = t; t } else (downs.remove(code) ?: t)
            val e = KeyEvent(t0, t, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0, meta,
                dev, Keys.scan(code), 0, InputDevice.SOURCE_KEYBOARD)
            m!!.invoke(im, e, 0) // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
        } catch (t: Throwable) { Log.e("Inj", "falha ao injetar tecla", t) }
    }
}

object Keys {
    val map: Map<String, Int> = linkedMapOf<String, Int>().apply {
        put("ESC", KeyEvent.KEYCODE_ESCAPE); put("TAB", KeyEvent.KEYCODE_TAB); put("CAPS", KeyEvent.KEYCODE_CAPS_LOCK)
        put("SHIFT", KeyEvent.KEYCODE_SHIFT_LEFT); put("CTRL", KeyEvent.KEYCODE_CTRL_LEFT); put("ALT", KeyEvent.KEYCODE_ALT_LEFT)
        put("WIN", KeyEvent.KEYCODE_META_LEFT); put("ENTER", KeyEvent.KEYCODE_ENTER); put("SPACE", KeyEvent.KEYCODE_SPACE)
        put("BKSP", KeyEvent.KEYCODE_DEL); put("DEL", KeyEvent.KEYCODE_FORWARD_DEL); put("INS", KeyEvent.KEYCODE_INSERT)
        put("HOME", KeyEvent.KEYCODE_MOVE_HOME); put("END", KeyEvent.KEYCODE_MOVE_END)
        put("PGUP", KeyEvent.KEYCODE_PAGE_UP); put("PGDN", KeyEvent.KEYCODE_PAGE_DOWN)
        put("UP", KeyEvent.KEYCODE_DPAD_UP); put("DOWN", KeyEvent.KEYCODE_DPAD_DOWN)
        put("LEFT", KeyEvent.KEYCODE_DPAD_LEFT); put("RIGHT", KeyEvent.KEYCODE_DPAD_RIGHT)
        for (i in 1..12) put("F$i", KeyEvent.KEYCODE_F1 + i - 1)
        for (c in 'A'..'Z') put("$c", KeyEvent.KEYCODE_A + (c - 'A'))
        for (n in 0..9) put("$n", KeyEvent.KEYCODE_0 + n)
    }

    // códigos de scan (Linux) — alguns jogos/emuladores leem o scancode em vez do keycode
    private val sc = HashMap<Int, Int>().apply {
        "QWERTYUIOP".forEachIndexed { i, c -> put(KeyEvent.KEYCODE_A + (c - 'A'), 16 + i) }
        "ASDFGHJKL".forEachIndexed { i, c -> put(KeyEvent.KEYCODE_A + (c - 'A'), 30 + i) }
        "ZXCVBNM".forEachIndexed { i, c -> put(KeyEvent.KEYCODE_A + (c - 'A'), 44 + i) }
        for (n in 1..9) put(KeyEvent.KEYCODE_0 + n, 1 + n)
        put(KeyEvent.KEYCODE_0, 11)
        for (i in 0..9) put(KeyEvent.KEYCODE_F1 + i, 59 + i)
        put(KeyEvent.KEYCODE_F11, 87); put(KeyEvent.KEYCODE_F12, 88)
        putAll(mapOf(KeyEvent.KEYCODE_ESCAPE to 1, KeyEvent.KEYCODE_TAB to 15, KeyEvent.KEYCODE_CAPS_LOCK to 58,
            KeyEvent.KEYCODE_SHIFT_LEFT to 42, KeyEvent.KEYCODE_CTRL_LEFT to 29, KeyEvent.KEYCODE_ALT_LEFT to 56,
            KeyEvent.KEYCODE_META_LEFT to 125, KeyEvent.KEYCODE_ENTER to 28, KeyEvent.KEYCODE_SPACE to 57,
            KeyEvent.KEYCODE_DEL to 14, KeyEvent.KEYCODE_FORWARD_DEL to 111, KeyEvent.KEYCODE_INSERT to 110,
            KeyEvent.KEYCODE_MOVE_HOME to 102, KeyEvent.KEYCODE_MOVE_END to 107, KeyEvent.KEYCODE_PAGE_UP to 104,
            KeyEvent.KEYCODE_PAGE_DOWN to 109, KeyEvent.KEYCODE_DPAD_UP to 103, KeyEvent.KEYCODE_DPAD_DOWN to 108,
            KeyEvent.KEYCODE_DPAD_LEFT to 105, KeyEvent.KEYCODE_DPAD_RIGHT to 106))
    }
    fun scan(c: Int) = sc[c] ?: 0

    fun meta(c: Int) = when (c) {
        KeyEvent.KEYCODE_SHIFT_LEFT -> KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        KeyEvent.KEYCODE_CTRL_LEFT -> KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        KeyEvent.KEYCODE_ALT_LEFT -> KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        KeyEvent.KEYCODE_META_LEFT -> KeyEvent.META_META_ON or KeyEvent.META_META_LEFT_ON
        KeyEvent.KEYCODE_CAPS_LOCK -> KeyEvent.META_CAPS_LOCK_ON
        else -> 0
    }
}
