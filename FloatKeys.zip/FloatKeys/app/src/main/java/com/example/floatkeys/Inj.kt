package com.example.floatkeys

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.MotionEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

/** Injeta eventos via IInputManager (shell/Shizuku) ou cria dispositivos HID reais (UHID): teclado, mouse e gamepad. */
object Inj {
    private var im: Any? = null
    private var m: java.lang.reflect.Method? = null
    private val downs = HashMap<Int, Long>()

    private var uhid: IUhid? = null
    private var bound = false
    private var mode = 0                      // 0 injeção · 1 teclado+mouse USB · 2 teclado+mouse Bluetooth · 3 gamepad
    @Volatile var kbOn = false
    @Volatile var mouseOn = false
    private val pressed = LinkedHashSet<Int>()
    private var mods = 0
    private var mbtn = 0

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName("com.example.floatkeys", UhidService::class.java.name))
            .daemon(false).processNameSuffix("uhid").debuggable(false).version(1)
    }
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            val u = IUhid.Stub.asInterface(b); uhid = u
            try {
                if (mode == 3) Pad.on = u.startPad()
                else if (mode > 0) { val bus = if (mode == 1) 3 else 5; kbOn = u.start(bus); mouseOn = u.startMouse(bus) }
            } catch (e: Throwable) { Log.e("Inj", "uhid", e) }
        }
        override fun onServiceDisconnected(n: ComponentName?) { uhid = null; kbOn = false; mouseOn = false; Pad.on = false }
    }

    private val usage = HashMap<Int, Int>().apply {
        for (c in 0..25) put(KeyEvent.KEYCODE_A + c, 4 + c)
        for (n in 1..9) put(KeyEvent.KEYCODE_0 + n, 0x1D + n)
        put(KeyEvent.KEYCODE_0, 0x27)
        for (i in 0..11) put(KeyEvent.KEYCODE_F1 + i, 0x3A + i)
        putAll(mapOf(KeyEvent.KEYCODE_ENTER to 0x28, KeyEvent.KEYCODE_ESCAPE to 0x29, KeyEvent.KEYCODE_DEL to 0x2A,
            KeyEvent.KEYCODE_TAB to 0x2B, KeyEvent.KEYCODE_SPACE to 0x2C, KeyEvent.KEYCODE_CAPS_LOCK to 0x39,
            KeyEvent.KEYCODE_INSERT to 0x49, KeyEvent.KEYCODE_MOVE_HOME to 0x4A, KeyEvent.KEYCODE_PAGE_UP to 0x4B,
            KeyEvent.KEYCODE_FORWARD_DEL to 0x4C, KeyEvent.KEYCODE_MOVE_END to 0x4D, KeyEvent.KEYCODE_PAGE_DOWN to 0x4E,
            KeyEvent.KEYCODE_DPAD_RIGHT to 0x4F, KeyEvent.KEYCODE_DPAD_LEFT to 0x50, KeyEvent.KEYCODE_DPAD_DOWN to 0x51,
            KeyEvent.KEYCODE_DPAD_UP to 0x52))
    }
    private val modBit = mapOf(KeyEvent.KEYCODE_CTRL_LEFT to 1, KeyEvent.KEYCODE_SHIFT_LEFT to 2,
        KeyEvent.KEYCODE_ALT_LEFT to 4, KeyEvent.KEYCODE_META_LEFT to 8)

    fun configure(md: Int) {
        if (bound && md != mode) hid(false)
        mode = md; hid(md > 0)
    }

    fun hid(enable: Boolean) {
        try {
            if (enable && !bound && ready()) { bound = true; Shizuku.bindUserService(args, conn) }
            else if (!enable && bound) {
                Pad.reset(); Shizuku.unbindUserService(args, conn, true)
                bound = false; uhid = null; kbOn = false; mouseOn = false; Pad.on = false; pressed.clear(); mods = 0; mbtn = 0
            }
        } catch (e: Throwable) { Log.e("Inj", "uhid", e); bound = false }
    }

    private fun hidSend(code: Int, down: Boolean): Boolean {
        val mb = modBit[code]
        if (mb != null) mods = if (down) mods or mb else mods and mb.inv()
        else { val u = usage[code] ?: return false; if (down) pressed.add(u) else pressed.remove(u) }
        val r = ByteArray(8); r[0] = mods.toByte()
        pressed.take(6).forEachIndexed { i, u -> r[2 + i] = u.toByte() }
        return try { uhid?.report(r); uhid != null } catch (e: Throwable) { kbOn = false; false }
    }

    fun pad(data: ByteArray) { try { uhid?.pad(data) } catch (e: Throwable) { Pad.on = false } }

    /** bit: 1 esquerdo · 2 direito · 4 meio */
    fun mouseBtn(bit: Int, down: Boolean) { mbtn = if (down) mbtn or bit else mbtn and bit.inv(); mrep(0, 0, 0) }
    fun mouseMove(dx: Int, dy: Int, wheel: Int = 0) = mrep(dx, dy, wheel)
    private fun mrep(dx: Int, dy: Int, w: Int) {
        if (!mouseOn) return
        try {
            uhid?.mouse(byteArrayOf(mbtn.toByte(), dx.coerceIn(-127, 127).toByte(), dy.coerceIn(-127, 127).toByte(), w.coerceIn(-127, 127).toByte()))
        } catch (e: Throwable) { mouseOn = false }
    }

    fun ready() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun ensure() {
        if (m != null) return
        HiddenApiBypass.addHiddenApiExemptions("")
        val b = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
        im = Class.forName("android.hardware.input.IInputManager\$Stub")
            .getMethod("asInterface", IBinder::class.java).invoke(null, b)
        m = im!!.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.java)
    }

    fun send(code: Int, down: Boolean, meta: Int) {
        if (kbOn && hidSend(code, down)) return
        try {
            ensure()
            val t = SystemClock.uptimeMillis()
            val t0 = if (down) { downs[code] = t; t } else (downs.remove(code) ?: t)
            val e = KeyEvent(t0, t, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0, meta,
                KeyCharacterMap.VIRTUAL_KEYBOARD, Keys.scan(code), 0, InputDevice.SOURCE_KEYBOARD)
            m!!.invoke(im, e, 0) // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
        } catch (t: Throwable) { Log.e("Inj", "falha ao injetar tecla", t) }
    }
}

object Keys {
    val map: Map<String, Int> = linkedMapOf<String, Int>().apply {
        put("ESC", KeyEvent.KEYCODE_ESCAPE); put("TAB", KeyEvent.KEYCODE_TAB); put("CAPS", KeyEvent.KEYCODE_CAPS_LOCK)
        put("SHIFT", KeyEvent.KEYCODE_SHIFT_LEFT); put("CTRL", KeyEvent.KEYCODE_CTRL_LEFT); put("ALT", KeyEvent.KEYCODE_ALT_LEFT)
        put("WIN", KeyEvent.KEYCODE_META_LEFT); put("ENTER", KeyEvent.KEYCODE_ENTER); put("SPACE", KeyEvent.KEYCODE_SPACE)
        put("BKSP", KeyEvent.KEYCODE_DEL); put("DEL", KeyEvent.KEYCODE_FORWARD_DEL); put("INS", KeyEvent.KEYCODE_INSERT)
        put("HOME", KeyEvent.KEYCODE_MOVE_HOME); put("END", KeyEvent.KEYCODE_MOVE_END)
        put("PGUP", KeyEvent.KEYCODE_PAGE_UP); put("PGDN", KeyEvent.KEYCODE_PAGE_DOWN)
        put("UP", KeyEvent.KEYCODE_DPAD_UP); put("DOWN", KeyEvent.KEYCODE_DPAD_DOWN)
        put("LEFT", KeyEvent.KEYCODE_DPAD_LEFT); put("RIGHT", KeyEvent.KEYCODE_DPAD_RIGHT)
        for (i in 1..12) put("F$i", KeyEvent.KEYCODE_F1 + i - 1)
        for (c in 'A'..'Z') put("$c", KeyEvent.KEYCODE_A + (c - 'A'))
        for (n in 0..9) put("$n", KeyEvent.KEYCODE_0 + n)
        // botões especiais (>= 1000): analógico WASD, touchpad, mouse livre, cliques e roda
        put("JOY", 1000); put("PAD", 1001); put("LIVRE", 1002); put("M-ESQ", 1003); put("M-DIR", 1004); put("M-MEIO", 1005); put("RODA+", 1006); put("RODA-", 1007)
    }

    // códigos de scan (Linux) — alguns jogos/emuladores leem o scancode em vez do keycode
    private val sc = HashMap<Int, Int>().apply {
        "QWERTYUIOP".forEachIndexed { i, c -> put(KeyEvent.KEYCODE_A + (c - 'A'), 16 + i) }
        "ASDFGHJKL".forEachIndexed { i, c -> put(KeyEvent.KEYCODE_A + (c - 'A'), 30 + i) }
        "ZXCVBNM".forEachIndexed { i, c -> put(KeyEvent.KEYCODE_A + (c - 'A'), 44 + i) }
        for (n in 1..9) put(KeyEvent.KEYCODE_0 + n, 1 + n)
        put(KeyEvent.KEYCODE_0, 11)
        for (i in 0..9) put(KeyEvent.KEYCODE_F1 + i, 59 + i)
        put(KeyEvent.KEYCODE_F11, 87); put(KeyEvent.KEYCODE_F12, 88)
        putAll(mapOf(KeyEvent.KEYCODE_ESCAPE to 1, KeyEvent.KEYCODE_TAB to 15, KeyEvent.KEYCODE_CAPS_LOCK to 58,
            KeyEvent.KEYCODE_SHIFT_LEFT to 42, KeyEvent.KEYCODE_CTRL_LEFT to 29, KeyEvent.KEYCODE_ALT_LEFT to 56,
            KeyEvent.KEYCODE_META_LEFT to 125, KeyEvent.KEYCODE_ENTER to 28, KeyEvent.KEYCODE_SPACE to 57,
            KeyEvent.KEYCODE_DEL to 14, KeyEvent.KEYCODE_FORWARD_DEL to 111, KeyEvent.KEYCODE_INSERT to 110,
            KeyEvent.KEYCODE_MOVE_HOME to 102, KeyEvent.KEYCODE_MOVE_END to 107, KeyEvent.KEYCODE_PAGE_UP to 104,
            KeyEvent.KEYCODE_PAGE_DOWN to 109, KeyEvent.KEYCODE_DPAD_UP to 103, KeyEvent.KEYCODE_DPAD_DOWN to 108,
            KeyEvent.KEYCODE_DPAD_LEFT to 105, KeyEvent.KEYCODE_DPAD_RIGHT to 106))
    }
    fun scan(c: Int) = sc[c] ?: 0

    fun meta(c: Int) = when (c) {
        KeyEvent.KEYCODE_SHIFT_LEFT -> KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        KeyEvent.KEYCODE_CTRL_LEFT -> KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        KeyEvent.KEYCODE_ALT_LEFT -> KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        KeyEvent.KEYCODE_META_LEFT -> KeyEvent.META_META_ON or KeyEvent.META_META_LEFT_ON
        KeyEvent.KEYCODE_CAPS_LOCK -> KeyEvent.META_CAPS_LOCK_ON
        else -> 0
    }
}

/** Gamepad virtual (HID real): teclas do FloatKeys viram analógicos, D-pad e botões que jogos como o Roblox aceitam. */
object Pad {
    @Volatile var on = false
    val names = listOf("Teclado normal",
        "Analógico esq ↑", "Analógico esq ←", "Analógico esq ↓", "Analógico esq →",
        "Analógico dir ↑ (câmera)", "Analógico dir ←", "Analógico dir ↓", "Analógico dir →",
        "D-pad ↑", "D-pad ←", "D-pad ↓", "D-pad →",
        "Botão A (pular)", "Botão B", "Botão X", "Botão Y", "L1", "R1", "L2", "R2", "Start", "Select")
    val short = listOf("", "L↑", "L←", "L↓", "L→", "R↑", "R←", "R↓", "R→", "↑", "←", "↓", "→", "A", "B", "X", "Y", "L1", "R1", "L2", "R2", "ST", "SE")
    private val held = HashSet<Int>()
    private val bits = intArrayOf(0, 1, 3, 4, 6, 7, 8, 9, 11, 10)   // A B X Y L1 R1 L2 R2 Start Select

    fun reset() { held.clear(); if (on) send() }

    fun set(fn: Int, down: Boolean) {
        if (down) held.add(fn) else held.remove(fn)
        send()
    }

    private fun send() {
        var lx = 0; var ly = 0; var rx = 0; var ry = 0; var hx = 0; var hy = 0; var b = 0
        for (f in held) {
            when (f) {
                1 -> ly -= 127
                2 -> lx -= 127
                3 -> ly += 127
                4 -> lx += 127
                5 -> ry -= 127
                6 -> rx -= 127
                7 -> ry += 127
                8 -> rx += 127
                9 -> hy -= 1
                10 -> hx -= 1
                11 -> hy += 1
                12 -> hx += 1
                in 13..22 -> b = b or (1 shl bits[f - 13])
            }
        }
        val hat = when {
            hx == 0 && hy < 0 -> 0
            hx > 0 && hy < 0 -> 1
            hx > 0 && hy == 0 -> 2
            hx > 0 && hy > 0 -> 3
            hx == 0 && hy > 0 -> 4
            hx < 0 && hy > 0 -> 5
            hx < 0 && hy == 0 -> 6
            hx < 0 && hy < 0 -> 7
            else -> 8
        }
        Inj.pad(byteArrayOf((b and 0xFF).toByte(), (b shr 8).toByte(), lx.toByte(), ly.toByte(), rx.toByte(), ry.toByte(), hat.toByte()))
    }
}
