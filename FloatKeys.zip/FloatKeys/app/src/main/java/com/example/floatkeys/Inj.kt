package com.example.floatkeys

import android.content.pm.PackageManager
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

/** Injeta teclas no sistema inteiro via IInputManager (executado como shell pelo Shizuku). */
object Inj {
    private var im: Any? = null
    private var m: java.lang.reflect.Method? = null

    fun ready() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun send(code: Int, down: Boolean, meta: Int) {
        try {
            if (m == null) {
                HiddenApiBypass.addHiddenApiExemptions("")
                val b = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
                im = Class.forName("android.hardware.input.IInputManager\$Stub")
                    .getMethod("asInterface", IBinder::class.java).invoke(null, b)
                m = im!!.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.java)
            }
            val t = SystemClock.uptimeMillis()
            val e = KeyEvent(t, t, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0, meta,
                KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD)
            m!!.invoke(im, e, 0) // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
        } catch (t: Throwable) { Log.e("Inj", "falha ao injetar tecla", t) }
    }
}

object Keys {
    val map: Map<String, Int> = linkedMapOf<String, Int>().apply {
        put("ESC", KeyEvent.KEYCODE_ESCAPE); put("TAB", KeyEvent.KEYCODE_TAB); put("CAPS", KeyEvent.KEYCODE_CAPS_LOCK)
        put("SHIFT", KeyEvent.KEYCODE_SHIFT_LEFT); put("CTRL", KeyEvent.KEYCODE_CTRL_LEFT); put("ALT", KeyEvent.KEYCODE_ALT_LEFT)
        put("WIN", KeyEvent.KEYCODE_META_LEFT); put("ENTER", KeyEvent.KEYCODE_ENTER); put("SPACE", KeyEvent.KEYCODE_SPACE)
        put("BKSP", KeyEvent.KEYCODE_DEL); put("DEL", KeyEvent.KEYCODE_FORWARD_DEL); put("INS", KeyEvent.KEYCODE_INSERT)
        put("HOME", KeyEvent.KEYCODE_MOVE_HOME); put("END", KeyEvent.KEYCODE_MOVE_END)
        put("PGUP", KeyEvent.KEYCODE_PAGE_UP); put("PGDN", KeyEvent.KEYCODE_PAGE_DOWN)
        put("UP", KeyEvent.KEYCODE_DPAD_UP); put("DOWN", KeyEvent.KEYCODE_DPAD_DOWN)
        put("LEFT", KeyEvent.KEYCODE_DPAD_LEFT); put("RIGHT", KeyEvent.KEYCODE_DPAD_RIGHT)
        for (i in 1..12) put("F$i", KeyEvent.KEYCODE_F1 + i - 1)
        for (c in 'A'..'Z') put("$c", KeyEvent.KEYCODE_A + (c - 'A'))
        for (n in 0..9) put("$n", KeyEvent.KEYCODE_0 + n)
    }

    fun meta(c: Int) = when (c) {
        KeyEvent.KEYCODE_SHIFT_LEFT -> KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        KeyEvent.KEYCODE_CTRL_LEFT -> KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        KeyEvent.KEYCODE_ALT_LEFT -> KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        KeyEvent.KEYCODE_META_LEFT -> KeyEvent.META_META_ON or KeyEvent.META_META_LEFT_ON
        KeyEvent.KEYCODE_CAPS_LOCK -> KeyEvent.META_CAPS_LOCK_ON
        else -> 0
    }
}
