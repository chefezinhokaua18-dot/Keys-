package com.example.floatkeys

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/** Tecla: posição/tamanho em dp "base" (100%); a escala de largura/altura do teclado é aplicada por cima. */
class K(var label: String, var code: Int, var x: Float, var y: Float, var w: Float, var h: Float,
        var mode: Int = 0, var tx: Int = 0, var ty: Int = 0, var name: String = "", var shape: Int = 0, var op: Int = 0, var loop: Boolean = false, var macro: String = "")  // mode: 0 tecla, 1 toque, 2-5 joystick ↑←↓→

val PALETTE = intArrayOf(0xFF334155.toInt(), 0xFF1D4ED8.toInt(), 0xFF7C3AED.toInt(), 0xFFBE123C.toInt(), 0xFF047857.toInt(), 0xFFEA580C.toInt())
val ACCENT = 0xFF22D3EE.toInt()
val PRIMARY = 0xFF6366F1.toInt()

/** Círculo do analógico: desenha a bolinha que acompanha o dedo. */
class StickView(c: Context) : TextView(c) {
    var kx = 0f; var ky = 0f
    private val pt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xDDFFFFFF.toInt() }
    override fun onDraw(cv: Canvas) {
        super.onDraw(cv)
        val r = minOf(width, height) / 2f
        cv.drawCircle(width / 2f + kx * r * .55f, height / 2f + ky * r * .55f, r * .3f, pt)
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var bp: WindowManager.LayoutParams
    private lateinit var tbp: WindowManager.LayoutParams
    private var bubble: TextView? = null
    private var tb: View? = null
    private val keys = mutableListOf<K>()
    private val views = HashMap<K, TextView>()   // cada tecla é uma janela flutuante própria
    private val lps = HashMap<K, WindowManager.LayoutParams>()
    private val active = HashSet<K>()
    private var sel: K? = null
    private var edit = false
    private var shown = false
    private var sw = 100; private var sh = 100   // largura/altura do teclado (%)
    private var ka = 90; private var kc = 0; private var kr = 8; private var kstyle = 0   // opacidade, cor, arredondado
    private var ox = 0; private var oy = 0       // origem do teclado na tela (px)
    private var ix = 0; private var iy = 0
    private var cx = 0; private var cy = 0; private var sr = 60   // centro (px) e raio (dp) do joystick
    private val dirs = HashSet<Int>()
    private val marks = ArrayList<View>()
    private var tpad: View? = null
    private var free: TextView? = null      // janela do mouse livre (fica por baixo das teclas)
    private lateinit var fp: WindowManager.LayoutParams
    private var mouseMode = 0                 // 0 desligado · 1 mouse livre · 2 mouse jogo
    private var snap: String? = null          // layout ao abrir o editor (para Cancelar)
    private var discard = false
    private var curTag = ""                      // "p" retrato / "l" paisagem: cada um tem seu layout
    private val d get() = resources.displayMetrics.density
    private fun Int.dp() = (this * d).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val act = i?.action
        val first = bubble == null
        if (first) init() else if (act == null) { rm(bubble); makeBubble() }
        if (first || act == null) Inj.configure(prefs.getInt("hidmode", 0))
        when (act) {
            "edit" -> setEdit(true)
            "toggle" -> toggle()
            "bubble" -> bubble?.let { it.visibility = if (it.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
            "stop" -> stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        if (::wm.isInitialized) { hideKeys(); rm(bubble) }
        Inj.hid(false)
        super.onDestroy()
    }

    private fun init() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("kb", MODE_PRIVATE)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("kb2", "Painel FloatKeys", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String, c: Int) = PendingIntent.getForegroundService(this, c,
            Intent(this, OverlayService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 9, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "kb2").setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("FloatKeys ativo").setContentText("Use os botões para mostrar/esconder o painel")
            .setContentIntent(open).setOngoing(true)
            .addAction(android.R.drawable.ic_menu_view, "Teclado", pi("toggle", 1))
            .addAction(android.R.drawable.ic_menu_gallery, "Bolinha", pi("bubble", 2))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Parar", pi("stop", 3)).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        curTag = tag(); load(); makeBubble()
    }

    // ---------- persistência ----------
    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
        PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }

    private fun tag() = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) "l" else "p"

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (!::wm.isInitialized || tag() == curTag) return
        val wasShown = shown; val wasEdit = edit
        save(); hideKeys(); rm(bubble)
        curTag = tag(); load(); makeBubble()
        if (wasShown) showKeys()
        if (wasEdit) setEdit(true)
    }

    private fun load() {
        keys.clear(); active.clear()
        sw = 100; sh = 100; ka = 90; kc = 0; kr = 8; kstyle = 0
        ox = 16.dp(); oy = 100.dp()
        cx = 160.dp(); cy = 240.dp(); sr = 60
        bp = lp(-2, -2); bp.x = 0; bp.y = 300.dp()
        val own = prefs.getString("layout2_$curTag", null)
        val s = own ?: prefs.getString("layout2", null)   // sem layout nesta orientação: usa o antigo como base
        if (s == null) defaults() else {
            val o = JSONObject(s)
            sw = o.getInt("sw"); sh = o.getInt("sh"); ka = o.getInt("ka"); kc = o.getInt("kc"); kr = o.getInt("kr"); kstyle = o.optInt("ks", 0)
            if (own != null) { ox = o.getInt("ox"); oy = o.getInt("oy"); bp.x = o.getInt("bx"); bp.y = o.getInt("by") }
            if (own != null) { cx = o.optInt("cx", cx); cy = o.optInt("cy", cy); sr = o.optInt("sr", sr) }
            val a = o.getJSONArray("keys")
            for (i in 0 until a.length()) a.getJSONObject(i).let {
                keys += K(it.getString("l"), it.getInt("c"), it.getDouble("x").toFloat(), it.getDouble("y").toFloat(),
                    it.getDouble("w").toFloat(), it.getDouble("h").toFloat(), it.optInt("m", 0), it.optInt("tx", 0), it.optInt("ty", 0), it.optString("n", ""), it.optInt("sh", 0), it.optInt("op", 0), it.optBoolean("lp", false), it.optString("mc", ""))
            }
        }
        // garante que atalho e teclado fiquem dentro da tela
        val m = resources.displayMetrics; val bs = prefs.getInt("bsize", 52).dp()
        ox = ox.coerceIn(0, maxOf(0, m.widthPixels - 40.dp())); oy = oy.coerceIn(0, maxOf(0, m.heightPixels - 40.dp()))
        bp.x = bp.x.coerceIn(0, maxOf(0, m.widthPixels - bs)); bp.y = bp.y.coerceIn(0, maxOf(0, m.heightPixels - bs))
    }

    private fun save() {
        if (discard) return
        val ks = JSONArray()
        keys.forEach {
            ks.put(JSONObject().put("l", it.label).put("c", it.code).put("x", it.x.toDouble()).put("y", it.y.toDouble())
                .put("w", it.w.toDouble()).put("h", it.h.toDouble()).put("m", it.mode).put("tx", it.tx).put("ty", it.ty).put("n", it.name).put("sh", it.shape).put("op", it.op).put("lp", it.loop).put("mc", it.macro))
        }
        prefs.edit().putString("layout2_$curTag", JSONObject().put("sw", sw).put("sh", sh).put("ka", ka).put("kc", kc).put("kr", kr).put("ks", kstyle)
            .put("ox", ox).put("oy", oy).put("cx", cx).put("cy", cy).put("sr", sr).put("bx", bp.x).put("by", bp.y).put("keys", ks).toString()).apply()
    }

    private fun defaults() {
        listOf("ESC F1 F2 F3 F4 F5 F6", "TAB Q W E R T Y", "CAPS A S D F G ENTER", "SHIFT Z X C V B BKSP", "CTRL ALT SPACE LEFT UP DOWN RIGHT")
            .forEachIndexed { r, row ->
                row.split(" ").forEachIndexed { c, n -> keys += K(n, Keys.map[n]!!, c * 48f, r * 48f, 44f, 44f) }
            }
    }

    private fun rm(v: View?) { try { wm.removeView(v) } catch (e: Exception) { } }

    // ---------- gestos ----------
    private fun drag(start: () -> Unit, move: (Float, Float) -> Unit, tap: () -> Unit = {},
                     hold: (() -> Unit)? = null, end: () -> Unit = { save() }) = object : View.OnTouchListener {
        var sx = 0f; var sy = 0f; var moved = false; var held = false
        val h = Handler(Looper.getMainLooper())
        val r = Runnable { held = true; hold?.invoke() }
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            if (fromMouse(e)) return true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; moved = false; held = false; start(); if (hold != null) h.postDelayed(r, 600) }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) + abs(dy) > 14) { moved = true; h.removeCallbacks(r) }
                    if (moved && !held) move(dx, dy)
                }
                MotionEvent.ACTION_UP -> { h.removeCallbacks(r); if (!held) { if (moved) end() else tap() } }
                MotionEvent.ACTION_CANCEL -> h.removeCallbacks(r)
            }
            return true
        }
    }

    // ---------- atalho (bolinha) ----------
    private fun makeBubble() {
        bubble = TextView(this).apply {
            text = "⌨"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            alpha = prefs.getInt("balpha", 90) / 100f
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ACCENT, PRIMARY)).apply {
                shape = GradientDrawable.OVAL; setStroke(2.dp(), 0x66FFFFFF)
            }
            setOnTouchListener(drag({ ix = bp.x; iy = bp.y },
                { dx, dy -> bp.x = ix + dx.toInt(); bp.y = iy + dy.toInt(); wm.updateViewLayout(this, bp) },
                { toggleRadial() }, { setEdit(true) }))
        }
        bp.width = prefs.getInt("bsize", 52).dp(); bp.height = bp.width
        wm.addView(bubble, bp)
    }

    private fun toggle() { if (shown) hideKeys() else showKeys() }

    private fun showKeys() {
        if (shown) return
        if (!Inj.ready()) Toast.makeText(this, "Shizuku inativo ou sem permissão", Toast.LENGTH_LONG).show()
        keys.forEach { addKeyWindow(it) }
        shown = true
    }

    private fun hideKeys() {
        if (!shown) return
        if (edit) setEdit(false)
        active.forEach { if (it.code != KeyEvent.KEYCODE_CAPS_LOCK) Inj.send(it.code, false, 0) }
        active.clear(); Pad.reset(); joySet(emptySet()); Inj.mouseBtn(1, false); Inj.mouseBtn(2, false)
        pads.values.forEach { rm(it) }; pads.clear(); autoHeld.clear()
        views.values.forEach { rm(it) }; views.clear(); lps.clear()
        shown = false
    }

    private fun setEdit(on: Boolean) {
        if (on) { showKeys(); if (tb == null) { snap = prefs.getString("layout2_$curTag", null); buildToolbar() } } else { rm(tb); tb = null }
        edit = on; sel = null
        keys.forEach { paint(it) }
        syncProps()
        if (!on) save()
    }

    // ---------- teclas ----------
    private fun addKeyWindow(k: K) {
        val v: TextView = (when (k.code) { 1000 -> JoyView(this); in 1003..1007 -> MouseView(this, k.code); else -> TextView(this) }).apply {
            text = txt(k); setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 2
            typeface = Typeface.DEFAULT_BOLD; includeFontPadding = false
        }
        val p = lp(1, 1)
        views[k] = v; lps[k] = p
        layoutKey(k); paint(k)
        val ed = drag({ sel = k; ix = p.x; iy = p.y; keys.forEach { paint(it) }; syncProps() },
            { dx, dy -> p.x = ix + dx.toInt(); p.y = iy + dy.toInt(); wm.updateViewLayout(v, p) },
            end = { k.x = (p.x - ox) / d * 100f / sw; k.y = (p.y - oy) / d * 100f / sh; save() })
        v.setOnTouchListener { _, e -> if (fromMouse(e)) true else if (edit) ed.onTouch(v, e) else play(k, v, e) }
        v.setOnHoverListener { _, e -> if (e.actionMasked == MotionEvent.ACTION_HOVER_ENTER && !edit && Inj.mouseOn && fromMouse(e)) ghost(k); false }
        wm.addView(v, p)
    }

    private fun layoutKey(k: K) {
        val v = views[k] ?: return; val p = lps[k] ?: return
        p.x = ox + (k.x * sw / 100f * d).toInt(); p.y = oy + (k.y * sh / 100f * d).toInt()
        val wd = k.w * sw / 100f; val hd = k.h * sh / 100f
        p.width = (wd * d).toInt().coerceAtLeast(10); p.height = (hd * d).toInt().coerceAtLeast(10)
        v.textSize = minOf(hd * (if (k.name.isEmpty()) .38f else .27f), wd * 1.2f / maxOf(k.label.length, k.name.length, 2)).coerceIn(6f, 26f)
        if (v.isAttachedToWindow) wm.updateViewLayout(v, p)
    }

    private fun relayout() { keys.forEach { layoutKey(it); paint(it) } }

    private fun mix(c: Int, t: Float): Int {   // clareia a cor em direção ao branco
        return Color.rgb((Color.red(c) + (255 - Color.red(c)) * t).toInt(), (Color.green(c) + (255 - Color.green(c)) * t).toInt(),
            (Color.blue(c) + (255 - Color.blue(c)) * t).toInt())
    }

    private fun paint(k: K) {
        val s = edit && k === sel
        val on = k in active || (k.code == 1001 && 0 in pads) || (k.code == 1002 && 1 in pads) || (k.code == 1008 && 2 in pads)
        val fill = when (k.code) {
            1001, 1002, 1008 -> 0xFF5B21B6.toInt()
            else -> if (kstyle == 0) 0xFF111827.toInt() else PALETTE[kc]
        }
        val c = if (on) 0xFF2563EB.toInt() else fill
        val a = (if (k.op > 0) k.op * 255 / 100 else ka * (if (kstyle == 0) 190 else 255) / 100) shl 24
        val ring = when {
            s -> 0xFFFBBF24.toInt()
            kstyle == 0 -> if (kc == 0) 0xD9FFFFFF.toInt() else mix(PALETTE[kc], .45f)
            else -> 0x66FFFFFF
        }
        views[k]?.background = if (k.code == 1000) {
            if (s) GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0); setStroke(3.dp(), 0xFFFBBF24.toInt()) } else null
        } else (if (kstyle == 0) GradientDrawable().apply { setColor((c and 0xFFFFFF) or a) }
                else GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf((mix(c, .16f) and 0xFFFFFF) or a, (c and 0xFFFFFF) or a))).apply {
            cornerRadius = when (k.shape) { 1 -> 1000f; 2 -> 7 * d; else -> if (kstyle == 0) 1000f else kr * d }
            setStroke((if (s) 3 else if (kstyle == 0) 2 else 1).dp(), ring)
        }
    }

    private fun meta() = active.fold(0) { m, k -> m or Keys.meta(k.code) }

    private fun play(k: K, v: View, e: MotionEvent): Boolean {
        if (k.code >= 1000) return special(k, v, e)
        if (k.mode > 0 && Pad.on) return padKey(k, v, e)
        val mod = Keys.meta(k.code) != 0
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                v.alpha = .7f; v.scaleX = .92f; v.scaleY = .92f
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                if (!mod) Inj.send(k.code, true, meta()) else {
                    // SHIFT/CTRL/ALT/WIN: toque liga (segura), toque de novo solta. CAPS: clique + indicador.
                    val on = if (k in active) { active -= k; false } else { active += k; true }
                    if (k.code == KeyEvent.KEYCODE_CAPS_LOCK) { Inj.send(k.code, true, 0); Inj.send(k.code, false, 0) }
                    else Inj.send(k.code, on, meta())
                    paint(k)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f
                if (!mod) Inj.send(k.code, false, meta())
            }
        }
        return true
    }

    // ---------- mouse virtual, analógico WASD e botões especiais ----------
    private val joyDown = HashSet<Int>()

    private fun joySet(want: Set<Int>) {
        joyDown.filter { it !in want }.forEach { Inj.send(it, false, meta()) }
        want.filter { it !in joyDown }.forEach { Inj.send(it, true, meta()) }
        joyDown.clear(); joyDown.addAll(want)
    }

    /** Analógico: arrastar dentro do círculo aperta W/A/S/D (inclusive diagonais) como nos mapeadores. */
    private fun joy(v: View, e: MotionEvent): Boolean {
        val sv = v as? JoyView
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
            sv?.kx = 0f; sv?.ky = 0f; sv?.invalidate(); joySet(emptySet()); return true
        }
        val r = minOf(v.width, v.height) / 2f
        var nx = (e.x - v.width / 2f) / r; var ny = (e.y - v.height / 2f) / r
        val len = kotlin.math.hypot(nx, ny)
        if (len > 1f) { nx /= len; ny /= len }
        sv?.kx = nx; sv?.ky = ny; sv?.invalidate()
        val mg = minOf(len, 1f)
        val want = HashSet<Int>()
        if (len > .28f) {
            if (ny < -mg * .38f) want += KeyEvent.KEYCODE_W
            if (ny > mg * .38f) want += KeyEvent.KEYCODE_S
            if (nx < -mg * .38f) want += KeyEvent.KEYCODE_A
            if (nx > mg * .38f) want += KeyEvent.KEYCODE_D
        }
        joySet(want)
        return true
    }

    private fun special(k: K, v: View, e: MotionEvent): Boolean {
        if (k.code == 1100) return macroKey(k, v, e)
        if (k.code == 1000) return joy(v, e)
        val a = e.actionMasked
        if (a == MotionEvent.ACTION_DOWN) {
            v.alpha = .7f; v.scaleX = .92f; v.scaleY = .92f
            when (k.code) {
                1001 -> togglePad(0)
                1002 -> togglePad(1)
                1008 -> togglePad(2)
                1003 -> btnDown(k, 1)
                1004 -> btnDown(k, 2)
                1005 -> Inj.mouseBtn(4, true)
                1006 -> Inj.mouseMove(0, 0, 1)
                1007 -> Inj.mouseMove(0, 0, -1)
            }
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f
            when (k.code) {
                1003 -> btnUp(k, 1)
                1004 -> btnUp(k, 2)
                1005 -> Inj.mouseBtn(4, false)
            }
        }
        return true
    }

    /** Livre/touchpad: 1 dedo move · toque rápido = clique · 2 dedos = botão direito. Jogo: arrastar segura o botão escolhido enquanto move. */
    private fun mouseTouch(kind: Int) = object : View.OnTouchListener {
        var lx = 0f; var ly = 0f; var t0 = 0L; var dist = 0f; var right = false; var skip = false
        var ax = 0f; var ay = 0f; var sx = 1.5f; var sy = 1.5f; var held = 0
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            if (fromMouse(e)) return true
            val game = kind == 2
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.requestUnbufferedDispatch(e)                  // recebe os toques sem esperar o quadro (menos atraso)
                    lx = e.x; ly = e.y; t0 = e.eventTime; dist = 0f; skip = false
                    sx = prefs.getInt("msx", 150) / 100f; sy = prefs.getInt("msy", 150) / 100f
                    if (game) { held = prefs.getInt("gamebtn", 0); if (held != 0) Inj.mouseBtn(held, true) }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (skip) { lx = e.x; ly = e.y; skip = false } else {
                        val dx = e.x - lx; val dy = e.y - ly; lx = e.x; ly = e.y
                        dist += abs(dx) + abs(dy)
                        ax += dx * sx; ay += dy * sy
                        val mx = ax.toInt(); val my = ay.toInt(); ax -= mx; ay -= my
                        if (mx != 0 || my != 0) Inj.mouseMove(mx, my)
                    }
                }
                MotionEvent.ACTION_POINTER_DOWN -> { if (!game && !right) { right = true; Inj.mouseBtn(2, true) }; skip = true }
                MotionEvent.ACTION_POINTER_UP -> { if (right && e.pointerCount <= 2) { right = false; Inj.mouseBtn(2, false) }; skip = true }
                MotionEvent.ACTION_UP -> {
                    if (right) { right = false; Inj.mouseBtn(2, false) }
                    else if (game) { if (held != 0) { Inj.mouseBtn(held, false); held = 0 } }
                    else if (dist < 20 && e.eventTime - t0 < 300) { Inj.mouseBtn(1, true); Inj.mouseBtn(1, false) }
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (right) { right = false; Inj.mouseBtn(2, false) }
                    if (held != 0) { Inj.mouseBtn(held, false); held = 0 }
                }
            }
            return true
        }
    }

    private fun needMouse(): Boolean {
        if (!Inj.mouseOn) Toast.makeText(this, "Ative \"Teclado + mouse\" (USB ou Bluetooth) no app e toque em Iniciar", Toast.LENGTH_LONG).show()
        return Inj.mouseOn
    }

    /** Eventos que vêm do próprio mouse virtual (HID) — o app NUNCA deve tratá-los como toque, senão entra em loop de cliques. */
    private fun fromMouse(e: MotionEvent) = e.isFromSource(InputDevice.SOURCE_MOUSE) || e.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE

    private val ghosts = HashMap<K, Runnable>()
    private val pads = HashMap<Int, View>()
    private val autoHeld = HashSet<K>()

    /** O cursor entrou em cima de uma tecla: ela fica "transparente" por um instante para o clique ir para o jogo. */
    private fun ghost(k: K) {
        val v = views[k] ?: return; val p = lps[k] ?: return
        ghosts.remove(k)?.let { handler.removeCallbacks(it) }
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        if (v.isAttachedToWindow) wm.updateViewLayout(v, p)
        val r = Runnable {
            ghosts.remove(k)
            val q = lps[k]
            if (q != null && v.isAttachedToWindow) { q.flags = q.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv(); wm.updateViewLayout(v, q) }
        }
        ghosts[k] = r; handler.postDelayed(r, 450)
    }

    /** Autoclique: em vez de segurar o botão (o Android descarta o movimento do mouse com botão segurado enquanto há um dedo na tela),
     *  clica repetidamente enquanto o botão do FloatKeys estiver pressionado. */
    private fun btnDown(k: K, bit: Int) {
        if (!k.loop) { Inj.mouseBtn(bit, true); return }
        autoHeld.add(k)
        val r = object : Runnable {
            override fun run() {
                if (k !in autoHeld) return
                Inj.mouseBtn(bit, true)
                handler.postDelayed({ Inj.mouseBtn(bit, false) }, 15)
                handler.postDelayed(this, 55)
            }
        }
        r.run()
    }

    private fun btnUp(k: K, bit: Int) { if (k.loop) autoHeld.remove(k) else Inj.mouseBtn(bit, false) }

    private fun autoPill(k: K): TextView {
        val b = pill("Autoclique: " + (if (k.loop) "Sim" else "Não")) {}
        b.setOnClickListener { k.loop = !k.loop; b.text = "Autoclique: " + (if (k.loop) "Sim" else "Não"); save() }
        return b
    }

    /** Janelas do mouse virtual: 0 = touchpad · 1 = mouse livre (maior) · 2 = área de câmera/jogo. Movíveis (≡) e redimensionáveis (⤡). */
    private fun togglePad(kind: Int) {
        pads.remove(kind)?.let { rm(it); keys.forEach { k -> paint(k) }; return }
        if (!needMouse()) return
        val m = resources.displayMetrics; val pf = arrayOf("tp", "fr", "gm")[kind]
        val dw = intArrayOf(260.dp(), (m.widthPixels * .5f).toInt(), (m.widthPixels * .38f).toInt())[kind]
        val dh = intArrayOf(170.dp(), (m.heightPixels * .6f).toInt(), (m.heightPixels * .7f).toInt())[kind]
        val dx = intArrayOf(24.dp(), m.widthPixels / 4, m.widthPixels - dw - 24.dp())[kind]
        val p = lp(prefs.getInt(pf + "w", dw), prefs.getInt(pf + "h", dh))
        p.x = prefs.getInt(pf + "x", dx); p.y = prefs.getInt(pf + "y", 60.dp())
        val saveP = { prefs.edit().putInt(pf + "x", p.x).putInt(pf + "y", p.y).putInt(pf + "w", p.width).putInt(pf + "h", p.height).apply() }
        val area = TextView(this).apply {
            text = arrayOf("TOUCHPAD", "MOUSE LIVRE", "CÂMERA / JOGO")[kind]
            setTextColor(0x55FFFFFF); gravity = Gravity.CENTER; textSize = 12f
            background = GradientDrawable().apply { cornerRadius = 12 * d; setColor(0x55000000); setStroke(1.dp(), 0x66FFFFFF) }
            setOnTouchListener(mouseTouch(kind))
        }
        val move = pill("≡") {}.apply {
            setOnTouchListener(drag({ ix = p.x; iy = p.y },
                { dx2, dy2 -> p.x = ix + dx2.toInt(); p.y = iy + dy2.toInt(); wm.updateViewLayout(pads[kind], p) }, end = { saveP() }))
        }
        val size = pill("⤡") {}.apply {
            setOnTouchListener(drag({ ix = p.width; iy = p.height },
                { dx2, dy2 -> p.width = (ix + dx2).toInt().coerceAtLeast(120.dp()); p.height = (iy + dy2).toInt().coerceAtLeast(90.dp()); wm.updateViewLayout(pads[kind], p) },
                end = { saveP() }))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(4.dp(), 2.dp(), 4.dp(), 4.dp())
            background = GradientDrawable().apply { cornerRadius = 16 * d; setColor(0xCC111827.toInt()) }
            addView(row(move, size, pill("✕") { togglePad(kind) }))
            addView(area, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        pads[kind] = box; wm.addView(box, p); keys.forEach { k -> paint(k) }
    }

    // ---------- propriedades de cada botão + macro ----------
    private val handler = Handler(Looper.getMainLooper())
    private val macroHeld = HashSet<K>()
    private var props: View? = null
    private var propsFor: K? = null

    /** Macro: teclas em sequência, combinações (SHIFT+E) e pausas (~200 = 200 ms). */
    private fun runMacro(k: K) {
        var t = 0L
        k.macro.split(" ").filter { it.isNotEmpty() }.forEach { tok ->
            if (tok.startsWith("~")) t += tok.drop(1).toLongOrNull() ?: 0L
            else {
                val codes = tok.split("+").mapNotNull { Keys.map[it] }
                val mt = codes.fold(0) { m, c -> m or Keys.meta(c) }
                handler.postDelayed({ codes.forEach { Inj.send(it, true, mt) } }, t)
                t += 45
                handler.postDelayed({ codes.reversed().forEach { Inj.send(it, false, 0) } }, t)
                t += 35
            }
        }
        if (k.loop) handler.postDelayed({ if (k in macroHeld) runMacro(k) }, t)
    }

    private fun macroKey(k: K, v: View, e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { v.alpha = .7f; v.scaleX = .92f; v.scaleY = .92f; macroHeld.add(k); runMacro(k) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f; macroHeld.remove(k) }
        }
        return true
    }

    private fun macroDialog(k: K) {
        val tc = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
        val tvv = TextView(tc).apply { textSize = 15f; setPadding(24.dp(), 14.dp(), 24.dp(), 10.dp()) }
        val lb = Button(tc).apply { isAllCaps = false; textSize = 12f }
        fun refresh() {
            tvv.text = if (k.macro.isEmpty()) "(vazia) Adicione teclas e pausas abaixo" else k.macro.replace("~", "⏱").replace(" ", "  ›  ")
            lb.text = "Repetir enquanto segura: " + (if (k.loop) "Sim" else "Não")
        }
        fun pick(title: String, items: Array<String>, f: (Int) -> Unit) {
            AlertDialog.Builder(tc).setTitle(title).setItems(items) { _, i -> f(i) }.create()
                .apply { window!!.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); show() }
        }
        val names = Keys.map.filter { it.value < 1000 }.keys.toTypedArray()
        val delays = arrayOf("50", "100", "200", "500", "1000")
        fun add(tok: String) { k.macro = (k.macro + " " + tok).trim(); refresh(); save() }
        fun b(t: String, f: () -> Unit) = Button(tc).apply {
            text = t; textSize = 12f; isAllCaps = false; setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        lb.setOnClickListener { k.loop = !k.loop; refresh(); save() }
        val box = LinearLayout(tc).apply {
            orientation = LinearLayout.VERTICAL
            addView(tvv)
            addView(LinearLayout(tc).apply {
                addView(b("+ Tecla") { pick("Tecla", names) { i -> add(names[i]) } })
                addView(b("+ Junto") {
                    pick("Junto com a anterior", names) { i ->
                        val t = k.macro.split(" ").filter { it.isNotEmpty() }.toMutableList()
                        if (t.isNotEmpty() && !t.last().startsWith("~")) t[t.size - 1] = t.last() + "+" + names[i] else t.add(names[i])
                        k.macro = t.joinToString(" "); refresh(); save()
                    }
                })
                addView(b("+ Pausa") { pick("Pausa (ms)", Array(delays.size) { delays[it] + " ms" }) { i -> add("~" + delays[i]) } })
            })
            addView(LinearLayout(tc).apply {
                addView(b("Desfazer") { k.macro = k.macro.trim().substringBeforeLast(" ", ""); refresh(); save() })
                addView(b("Limpar") { k.macro = ""; refresh(); save() })
            })
            addView(lb)
        }
        refresh()
        AlertDialog.Builder(tc).setTitle("Macro · " + k.name.ifEmpty { k.label }).setView(box).setPositiveButton("Pronto", null)
            .create().apply { window!!.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); show() }
    }

    /** Painel do botão selecionado: nome, formato, tamanho, opacidade e função/macro — cada botão é independente. */
    private fun syncProps() {
        val k = sel
        if (!edit || k == null) { rm(props); props = null; propsFor = null; return }
        if (propsFor === k && props != null) return
        rm(props); propsFor = k
        val forma = arrayOf("padrão", "redondo", "quadrado")
        val shapeBtn = pill("Formato: ${forma[k.shape]}") {}
        shapeBtn.setOnClickListener { k.shape = (k.shape + 1) % 3; shapeBtn.text = "Formato: ${forma[k.shape]}"; paint(k); save() }
        val title = TextView(this).apply {
            text = "Botão ${k.label}"; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; textSize = 14f
            setPadding(8.dp(), 8.dp(), 8.dp(), 8.dp()); layoutParams = LinearLayout.LayoutParams(0, -2, 2f)
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(10.dp(), 6.dp(), 10.dp(), 8.dp())
            background = GradientDrawable().apply { cornerRadius = 16 * d; setColor(0xE6111827.toInt()); setStroke(1.dp(), 0x55FFFFFF) }
            addView(row(title, pill("Fechar") { rm(props); props = null; propsFor = null }))
            addView(row(pill("Nome") { rename() }, shapeBtn,
                when { k.code == 1100 -> pill("Macro", PRIMARY) { macroDialog(k) }; k.code == 1003 || k.code == 1004 -> autoPill(k); else -> pill("Função ⟳") { pickFunction() } }))
            addView(row(seek("Tamanho", 16, 200, maxOf(k.w, k.h).toInt()) { v -> k.w = v.toFloat(); k.h = v.toFloat(); layoutKey(k) },
                seek("Opacidade %", 10, 100, if (k.op > 0) k.op else ka) { v -> k.op = v; paint(k) }))
        }
        props = card
        val p = lp(minOf(340.dp(), resources.displayMetrics.widthPixels - 16.dp()), -2)
        p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = 10.dp()
        wm.addView(card, p)
    }

    /** Dá um nome à tecla (aparece grande, com a tecla pequena embaixo, como no StarDesk: "Pular / Space"). */
    private fun rename() {
        val k = sel ?: run { Toast.makeText(this, "Toque numa tecla para selecioná-la", Toast.LENGTH_SHORT).show(); return }
        val tc = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
        val et = EditText(tc).apply { setText(k.name); hint = "Ex.: Pular"; setSingleLine() }
        AlertDialog.Builder(tc).setTitle("Nome da tecla ${k.label}").setView(et)
            .setPositiveButton("OK") { _, _ -> k.name = et.text.toString().trim().take(10); views[k]?.text = txt(k); layoutKey(k); save() }
            .setNegativeButton("Cancelar", null)
            .create().apply { window!!.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); show() }
    }

    /** Cancelar: descarta as mudanças feitas desde que o editor foi aberto. */
    private fun cancelEdit() {
        val sn = snap
        discard = true; hideKeys(); discard = false
        prefs.edit().apply { if (sn != null) putString("layout2_$curTag", sn) else remove("layout2_$curTag") }.apply()
        rm(bubble); keys.clear(); load(); makeBubble(); showKeys()
    }

    // ---------- roda de opções (toque na bolinha) ----------
    private class Opt(val ic: String, val lb: String, val col: Int, val act: () -> Unit)
    private var radial: View? = null

    private fun hideRadial() { rm(radial); radial = null }

    private fun toggleRadial() {
        if (radial != null) { hideRadial(); return }
        val m = resources.displayMetrics
        val rad = 90.dp(); val bs = 58.dp(); val box = 2 * rad + bs + 8.dp()
        val items = listOf(
            Opt("⌨", "Teclado", 0xFF2563EB.toInt()) { toggle() },
            Opt("✎", "Editar", 0xFFD97706.toInt()) { setEdit(true) },
            Opt("▭", "Touchpad", 0xFF7C3AED.toInt()) { togglePad(0) },
            Opt("🎯", "Jogo", 0xFF059669.toInt()) { togglePad(2) },
            Opt("🖱", "Livre", 0xFF0891B2.toInt()) { togglePad(1) },
            Opt("👁", "Sumir", 0xFF475569.toInt()) {
                bubble?.visibility = View.GONE
                Toast.makeText(this, "Use a notificação para mostrar a bolinha de novo", Toast.LENGTH_LONG).show()
            },
            Opt("⚙", "App", 0xFF4F46E5.toInt()) { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
            Opt("✕", "Parar", 0xFFDC2626.toInt()) { stopSelf() })
        val p = lp(box, box)
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        p.x = (bp.x + bp.width / 2 - box / 2).coerceIn(0, maxOf(0, m.widthPixels - box))
        p.y = (bp.y + bp.height / 2 - box / 2).coerceIn(0, maxOf(0, m.heightPixels - box))
        val root = FrameLayout(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x55000000) } }
        root.setOnTouchListener { _, e -> if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) hideRadial(); true }
        items.forEachIndexed { i, o ->
            val ang = Math.toRadians(-90.0 + i * 45.0); val c = box / 2f
            val b = TextView(this).apply {
                text = "${o.ic}\n${o.lb}"; setTextColor(Color.WHITE); gravity = Gravity.CENTER; textSize = 9.5f; typeface = Typeface.DEFAULT_BOLD
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(o.col); setStroke(2.dp(), 0x99FFFFFF.toInt()) }
                setOnClickListener { hideRadial(); o.act() }
            }
            root.addView(b, FrameLayout.LayoutParams(bs, bs).apply {
                leftMargin = (c + rad * Math.cos(ang)).toInt() - bs / 2; topMargin = (c + rad * Math.sin(ang)).toInt() - bs / 2
            })
        }
        radial = root; wm.addView(root, p)
    }

    // ---------- gamepad virtual ----------
    private fun sym(k: K) = if (k.mode in 1 until Pad.short.size) " " + Pad.short[k.mode] else ""

    private fun txt(k: K): CharSequence = when {
        k.code == 1000 || k.code in 1003..1007 -> ""
        k.name.isNotEmpty() -> SpannableString(k.name + "\n" + k.label + sym(k)).apply {
            setSpan(RelativeSizeSpan(.68f), k.name.length + 1, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        else -> k.label + sym(k)
    }

    private fun padKey(k: K, v: View, e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { v.alpha = .7f; v.scaleX = .92f; v.scaleY = .92f; Pad.set(k.mode, true) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f; Pad.set(k.mode, false) }
        }
        return true
    }

    private fun pickFunction() {
        val k = sel ?: run { Toast.makeText(this, "Toque numa tecla para selecioná-la", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_Alert))
            .setTitle("Função da tecla ${k.label}")
            .setItems(Pad.names.toTypedArray()) { _, i -> k.mode = i; views[k]?.text = txt(k); save() }
            .create().apply { window!!.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); show() }
    }

    private fun presetGame() {
        val m = mapOf("W" to 1, "A" to 2, "S" to 3, "D" to 4, "UP" to 5, "LEFT" to 6, "DOWN" to 7, "RIGHT" to 8,
            "SPACE" to 13, "F" to 14, "E" to 15, "Q" to 16)
        keys.forEach { k -> m[k.label]?.let { k.mode = it; views[k]?.text = txt(k) } }
        save()
        Toast.makeText(this, "WASD = analógico, setas = câmera, SPACE = pular", Toast.LENGTH_LONG).show()
    }

    // ---------- barra do editor ----------
    private fun pill(t: String, c: Int = 0xE62B3445.toInt(), f: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setPadding(8.dp(), 9.dp(), 8.dp(), 9.dp())
        background = GradientDrawable().apply { cornerRadius = 8 * d; setColor(c) }
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(3.dp(), 3.dp(), 3.dp(), 3.dp()) }
        setOnClickListener { f() }
    }

    private fun seek(t: String, min: Int, max: Int, cur: Int, on: (Int) -> Unit): View {
        val lbl = TextView(this).apply { setTextColor(0xFFCBD5E1.toInt()); textSize = 11f; text = "$t: $cur" }
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = cur - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { lbl.text = "$t: ${min + v}"; if (u) on(min + v) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { save() }
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; addView(lbl); addView(sb)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(4.dp(), 2.dp(), 4.dp(), 2.dp()) }
        }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply { v.forEach { addView(it) } }

    private fun buildToolbar() {
        tbp = lp(minOf(320.dp(), resources.displayMetrics.widthPixels - 16.dp()), -2).apply { x = 8.dp(); y = 48.dp() }
        val grip = TextView(this).apply {
            text = "≡  Editor do teclado"; setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            setPadding(8.dp(), 8.dp(), 8.dp(), 8.dp())
            setOnTouchListener(drag({ ix = tbp.x; iy = tbp.y }, { dx, dy -> tbp.x = ix + dx.toInt(); tbp.y = iy + dy.toInt(); wm.updateViewLayout(tb, tbp) }))
        }
        val moveAll = pill("✥ Mover tudo") {}.apply {
            setOnTouchListener(drag({ ix = ox; iy = oy }, { dx, dy -> ox = ix + dx.toInt(); oy = iy + dy.toInt(); relayout() }))
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(10.dp(), 6.dp(), 10.dp(), 8.dp())
            background = GradientDrawable().apply { cornerRadius = 18 * d; setColor(0xE6111827.toInt()); setStroke(1.dp(), 0x55FFFFFF) }
            addView(LinearLayout(this@OverlayService).apply {
                addView(grip, LinearLayout.LayoutParams(0, -2, 2f)); addView(pill("Cancelar") { cancelEdit() }); addView(pill("Salvar", 0xFF2563EB.toInt()) { setEdit(false) })
            })
            addView(row(pill("+ Tecla") { addKey() }, pill("Apagar", 0xFF7F1D1D.toInt()) {
                sel?.let { rm(views.remove(it)); lps.remove(it); keys -= it; sel = null; syncProps(); save() }
            }, pill("Cor") { kc = (kc + 1) % PALETTE.size; keys.forEach { paint(it) }; save() }, moveAll))
            addView(row(pill("Larg −") { resize(-4f, 0f) }, pill("Larg +") { resize(4f, 0f) },
                pill("Alt −") { resize(0f, -4f) }, pill("Alt +") { resize(0f, 4f) }))
            addView(row(pill("Função ⟳") { pickFunction() }, pill("Preset jogo") { presetGame() }, pill("Estilo") { kstyle = 1 - kstyle; keys.forEach { paint(it) }; save() }, pill("Nome") { rename() }))
            addView(row(seek("Largura teclado %", 30, 300, sw) { sw = it; relayout() },
                seek("Altura teclado %", 30, 300, sh) { sh = it; relayout() }))
            addView(row(seek("Opacidade %", 15, 100, ka) { ka = it; keys.forEach { k -> paint(k) } },
                seek("Arredondado", 0, 30, kr) { kr = it; keys.forEach { k -> paint(k) } }))
        }
        tb = card
        wm.addView(card, tbp)
    }

    private fun resize(dw: Float, dh: Float) {
        sel?.let { it.w = (it.w + dw).coerceAtLeast(16f); it.h = (it.h + dh).coerceAtLeast(16f); layoutKey(it); save() }
    }

    private fun addKey() {
        val names = Keys.map.keys.toTypedArray()
        AlertDialog.Builder(ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_Alert))
            .setTitle("Adicionar tecla")
            .setItems(names) { _, i ->
                val cd = Keys.map[names[i]]!!; val big = cd == 1000
                val sz = when { cd == 1000 -> 110f; cd in 1003..1007 || cd == 1100 -> 56f; else -> 44f }
                val k = K(names[i], cd, 8f, 8f, sz, sz)
                keys += k; addKeyWindow(k); sel = k; keys.forEach { paint(it) }; save(); syncProps(); if (cd == 1003 || cd == 1004) { k.loop = true; save() }; if (cd == 1100) macroDialog(k)
            }
            .create().apply { window!!.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); show() }
    }
}
