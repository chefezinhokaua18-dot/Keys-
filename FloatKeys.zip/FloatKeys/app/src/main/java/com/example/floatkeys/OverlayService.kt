package com.example.floatkeys

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/** Tecla: posição/tamanho em dp "base" (100%); a escala de largura/altura do teclado é aplicada por cima. */
class K(var label: String, var code: Int, var x: Float, var y: Float, var w: Float, var h: Float,
        var mode: Int = 0, var tx: Int = 0, var ty: Int = 0)  // mode: 0 tecla, 1 toque, 2-5 joystick ↑←↓→

val PALETTE = intArrayOf(0xFF334155.toInt(), 0xFF1D4ED8.toInt(), 0xFF7C3AED.toInt(), 0xFFBE123C.toInt(), 0xFF047857.toInt(), 0xFFEA580C.toInt())
val ACCENT = 0xFF22D3EE.toInt()
val PRIMARY = 0xFF6366F1.toInt()

/** Círculo do analógico: desenha a bolinha que acompanha o dedo. */
class StickView(c: Context) : TextView(c) {
    var kx = 0f; var ky = 0f
    private val pt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xDDFFFFFF.toInt() }
    override fun onDraw(cv: Canvas) {
        super.onDraw(cv)
        val r = minOf(width, height) / 2f
        cv.drawCircle(width / 2f + kx * r * .55f, height / 2f + ky * r * .55f, r * .3f, pt)
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var bp: WindowManager.LayoutParams
    private lateinit var tbp: WindowManager.LayoutParams
    private var bubble: TextView? = null
    private var tb: View? = null
    private val keys = mutableListOf<K>()
    private val views = HashMap<K, TextView>()   // cada tecla é uma janela flutuante própria
    private val lps = HashMap<K, WindowManager.LayoutParams>()
    private val active = HashSet<K>()
    private var sel: K? = null
    private var edit = false
    private var shown = false
    private var sw = 100; private var sh = 100   // largura/altura do teclado (%)
    private var ka = 90; private var kc = 0; private var kr = 8   // opacidade, cor, arredondado
    private var ox = 0; private var oy = 0       // origem do teclado na tela (px)
    private var ix = 0; private var iy = 0
    private var cx = 0; private var cy = 0; private var sr = 60   // centro (px) e raio (dp) do joystick
    private val dirs = HashSet<Int>()
    private val marks = ArrayList<View>()
    private var tpad: View? = null
    private var free: TextView? = null      // janela do mouse livre (fica por baixo das teclas)
    private lateinit var fp: WindowManager.LayoutParams
    private var freeOn = false
    private var curTag = ""                      // "p" retrato / "l" paisagem: cada um tem seu layout
    private val d get() = resources.displayMetrics.density
    private fun Int.dp() = (this * d).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (bubble == null) init() else { rm(bubble); makeBubble() }
        Inj.configure(prefs.getInt("hidmode", 0))
        if (i?.action == "edit") setEdit(true)
        return START_STICKY
    }

    override fun onDestroy() {
        if (::wm.isInitialized) { hideKeys(); rm(bubble) }
        Inj.hid(false)
        super.onDestroy()
    }

    private fun init() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("kb", MODE_PRIVATE)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("kb", "Teclado flutuante", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "kb").setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Teclado flutuante ativo").build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        curTag = tag(); load(); makeBubble()
    }

    // ---------- persistência ----------
    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
        PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }

    private fun tag() = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) "l" else "p"

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (!::wm.isInitialized || tag() == curTag) return
        val wasShown = shown; val wasEdit = edit
        save(); hideKeys(); rm(bubble)
        curTag = tag(); load(); makeBubble()
        if (wasShown) showKeys()
        if (wasEdit) setEdit(true)
    }

    private fun load() {
        keys.clear(); active.clear()
        sw = 100; sh = 100; ka = 90; kc = 0; kr = 8
        ox = 16.dp(); oy = 100.dp()
        cx = 160.dp(); cy = 240.dp(); sr = 60
        bp = lp(-2, -2); bp.x = 0; bp.y = 300.dp()
        val own = prefs.getString("layout2_$curTag", null)
        val s = own ?: prefs.getString("layout2", null)   // sem layout nesta orientação: usa o antigo como base
        if (s == null) defaults() else {
            val o = JSONObject(s)
            sw = o.getInt("sw"); sh = o.getInt("sh"); ka = o.getInt("ka"); kc = o.getInt("kc"); kr = o.getInt("kr")
            if (own != null) { ox = o.getInt("ox"); oy = o.getInt("oy"); bp.x = o.getInt("bx"); bp.y = o.getInt("by") }
            if (own != null) { cx = o.optInt("cx", cx); cy = o.optInt("cy", cy); sr = o.optInt("sr", sr) }
            val a = o.getJSONArray("keys")
            for (i in 0 until a.length()) a.getJSONObject(i).let {
                keys += K(it.getString("l"), it.getInt("c"), it.getDouble("x").toFloat(), it.getDouble("y").toFloat(),
                    it.getDouble("w").toFloat(), it.getDouble("h").toFloat(), it.optInt("m", 0), it.optInt("tx", 0), it.optInt("ty", 0))
            }
        }
        // garante que atalho e teclado fiquem dentro da tela
        val m = resources.displayMetrics; val bs = prefs.getInt("bsize", 52).dp()
        ox = ox.coerceIn(0, maxOf(0, m.widthPixels - 40.dp())); oy = oy.coerceIn(0, maxOf(0, m.heightPixels - 40.dp()))
        bp.x = bp.x.coerceIn(0, maxOf(0, m.widthPixels - bs)); bp.y = bp.y.coerceIn(0, maxOf(0, m.heightPixels - bs))
    }

    private fun save() {
        val ks = JSONArray()
        keys.forEach {
            ks.put(JSONObject().put("l", it.label).put("c", it.code).put("x", it.x.toDouble()).put("y", it.y.toDouble())
                .put("w", it.w.toDouble()).put("h", it.h.toDouble()).put("m", it.mode).put("tx", it.tx).put("ty", it.ty))
        }
        prefs.edit().putString("layout2_$curTag", JSONObject().put("sw", sw).put("sh", sh).put("ka", ka).put("kc", kc).put("kr", kr)
            .put("ox", ox).put("oy", oy).put("cx", cx).put("cy", cy).put("sr", sr).put("bx", bp.x).put("by", bp.y).put("keys", ks).toString()).apply()
    }

    private fun defaults() {
        listOf("ESC F1 F2 F3 F4 F5 F6", "TAB Q W E R T Y", "CAPS A S D F G ENTER", "SHIFT Z X C V B BKSP", "CTRL ALT SPACE LEFT UP DOWN RIGHT")
            .forEachIndexed { r, row ->
                row.split(" ").forEachIndexed { c, n -> keys += K(n, Keys.map[n]!!, c * 48f, r * 44f, 44f, 40f) }
            }
    }

    private fun rm(v: View?) { try { wm.removeView(v) } catch (e: Exception) { } }

    // ---------- gestos ----------
    private fun drag(start: () -> Unit, move: (Float, Float) -> Unit, tap: () -> Unit = {},
                     hold: (() -> Unit)? = null, end: () -> Unit = { save() }) = object : View.OnTouchListener {
        var sx = 0f; var sy = 0f; var moved = false; var held = false
        val h = Handler(Looper.getMainLooper())
        val r = Runnable { held = true; hold?.invoke() }
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; moved = false; held = false; start(); if (hold != null) h.postDelayed(r, 600) }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) + abs(dy) > 14) { moved = true; h.removeCallbacks(r) }
                    if (moved && !held) move(dx, dy)
                }
                MotionEvent.ACTION_UP -> { h.removeCallbacks(r); if (!held) { if (moved) end() else tap() } }
                MotionEvent.ACTION_CANCEL -> h.removeCallbacks(r)
            }
            return true
        }
    }

    // ---------- atalho (bolinha) ----------
    private fun makeBubble() {
        bubble = TextView(this).apply {
            text = "⌨"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            alpha = prefs.getInt("balpha", 90) / 100f
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ACCENT, PRIMARY)).apply {
                shape = GradientDrawable.OVAL; setStroke(2.dp(), 0x66FFFFFF)
            }
            setOnTouchListener(drag({ ix = bp.x; iy = bp.y },
                { dx, dy -> bp.x = ix + dx.toInt(); bp.y = iy + dy.toInt(); wm.updateViewLayout(this, bp) },
                { toggle() }, { setEdit(true) }))
        }
        bp.width = prefs.getInt("bsize", 52).dp(); bp.height = bp.width
        wm.addView(bubble, bp)
    }

    private fun toggle() { if (shown) hideKeys() else showKeys() }

    private fun showKeys() {
        if (shown) return
        if (!Inj.ready()) Toast.makeText(this, "Shizuku inativo ou sem permissão", Toast.LENGTH_LONG).show()
        fp = lp(-1, -1); fp.flags = fp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; freeOn = false
        free = TextView(this).apply {
            visibility = View.GONE; text = "MOUSE LIVRE · toque em LIVRE para sair"; setTextColor(0x88FFFFFF.toInt()); textSize = 11f
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; setPadding(0, 24.dp(), 0, 0)
            background = GradientDrawable().apply { setColor(0x14FFFFFF); setStroke(2.dp(), 0x8822D3EE.toInt()) }
            setOnTouchListener(mouseTouch())
        }
        wm.addView(free, fp)
        keys.forEach { addKeyWindow(it) }
        shown = true
    }

    private fun hideKeys() {
        if (!shown) return
        if (edit) setEdit(false)
        active.forEach { if (it.code != KeyEvent.KEYCODE_CAPS_LOCK) Inj.send(it.code, false, 0) }
        active.clear(); Pad.reset(); joySet(emptySet()); Inj.mouseBtn(1, false); Inj.mouseBtn(2, false)
        rm(tpad); tpad = null; rm(free); free = null; freeOn = false
        views.values.forEach { rm(it) }; views.clear(); lps.clear()
        shown = false
    }

    private fun setEdit(on: Boolean) {
        if (on) { showKeys(); if (tb == null) buildToolbar() } else { rm(tb); tb = null }
        edit = on; sel = null
        keys.forEach { paint(it) }
        if (!on) save()
    }

    // ---------- teclas ----------
    private fun addKeyWindow(k: K) {
        val v: TextView = (if (k.code == 1000) StickView(this) else TextView(this)).apply {
            text = if (k.code == 1000) "" else k.label + sym(k); setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 1
            typeface = Typeface.DEFAULT_BOLD; includeFontPadding = false
        }
        val p = lp(1, 1)
        views[k] = v; lps[k] = p
        layoutKey(k); paint(k)
        val ed = drag({ sel = k; ix = p.x; iy = p.y; keys.forEach { paint(it) } },
            { dx, dy -> p.x = ix + dx.toInt(); p.y = iy + dy.toInt(); wm.updateViewLayout(v, p) },
            end = { k.x = (p.x - ox) / d * 100f / sw; k.y = (p.y - oy) / d * 100f / sh; save() })
        v.setOnTouchListener { _, e -> if (edit) ed.onTouch(v, e) else play(k, v, e) }
        wm.addView(v, p)
    }

    private fun layoutKey(k: K) {
        val v = views[k] ?: return; val p = lps[k] ?: return
        p.x = ox + (k.x * sw / 100f * d).toInt(); p.y = oy + (k.y * sh / 100f * d).toInt()
        val wd = k.w * sw / 100f; val hd = k.h * sh / 100f
        p.width = (wd * d).toInt().coerceAtLeast(10); p.height = (hd * d).toInt().coerceAtLeast(10)
        v.textSize = minOf(hd * .38f, wd * 1.5f / maxOf(k.label.length, 2)).coerceIn(6f, 26f)
        if (v.isAttachedToWindow) wm.updateViewLayout(v, p)
    }

    private fun relayout() { keys.forEach { layoutKey(it); paint(it) } }

    private fun paint(k: K) {
        val s = edit && k === sel
        val on = k in active || (k.code == 1001 && tpad != null) || (k.code == 1002 && freeOn)
        val c = if (on) ACCENT else PALETTE[kc]
        views[k]?.background = GradientDrawable().apply {
            cornerRadius = if (k.code == 1000) 1000f else kr * d
            setColor((c and 0xFFFFFF) or ((ka * 255 / 100) shl 24))
            setStroke((if (s) 3 else 1).dp(), if (s) 0xFFFBBF24.toInt() else 0x55FFFFFF)
        }
    }

    private fun meta() = active.fold(0) { m, k -> m or Keys.meta(k.code) }

    private fun play(k: K, v: View, e: MotionEvent): Boolean {
        if (k.code >= 1000) return special(k, v, e)
        if (k.mode > 0 && Pad.on) return padKey(k, v, e)
        val mod = Keys.meta(k.code) != 0
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                v.alpha = .7f; v.scaleX = .92f; v.scaleY = .92f
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                if (!mod) Inj.send(k.code, true, meta()) else {
                    // SHIFT/CTRL/ALT/WIN: toque liga (segura), toque de novo solta. CAPS: clique + indicador.
                    val on = if (k in active) { active -= k; false } else { active += k; true }
                    if (k.code == KeyEvent.KEYCODE_CAPS_LOCK) { Inj.send(k.code, true, 0); Inj.send(k.code, false, 0) }
                    else Inj.send(k.code, on, meta())
                    paint(k)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f
                if (!mod) Inj.send(k.code, false, meta())
            }
        }
        return true
    }

    // ---------- mouse virtual, analógico WASD e botões especiais ----------
    private val joyDown = HashSet<Int>()

    private fun joySet(want: Set<Int>) {
        joyDown.filter { it !in want }.forEach { Inj.send(it, false, meta()) }
        want.filter { it !in joyDown }.forEach { Inj.send(it, true, meta()) }
        joyDown.clear(); joyDown.addAll(want)
    }

    /** Analógico: arrastar dentro do círculo aperta W/A/S/D (inclusive diagonais) como nos mapeadores. */
    private fun joy(v: View, e: MotionEvent): Boolean {
        val sv = v as? StickView
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
            sv?.kx = 0f; sv?.ky = 0f; sv?.invalidate(); joySet(emptySet()); return true
        }
        val r = minOf(v.width, v.height) / 2f
        val nx = ((e.x - v.width / 2f) / r).coerceIn(-1f, 1f)
        val ny = ((e.y - v.height / 2f) / r).coerceIn(-1f, 1f)
        sv?.kx = nx; sv?.ky = ny; sv?.invalidate()
        val want = HashSet<Int>()
        if (ny < -.35f) want += KeyEvent.KEYCODE_W
        if (ny > .35f) want += KeyEvent.KEYCODE_S
        if (nx < -.35f) want += KeyEvent.KEYCODE_A
        if (nx > .35f) want += KeyEvent.KEYCODE_D
        joySet(want)
        return true
    }

    private fun special(k: K, v: View, e: MotionEvent): Boolean {
        if (k.code == 1000) return joy(v, e)
        val a = e.actionMasked
        if (a == MotionEvent.ACTION_DOWN) {
            v.alpha = .7f; v.scaleX = .92f; v.scaleY = .92f
            when (k.code) {
                1001 -> toggleTouchpad()
                1002 -> toggleFree()
                1003 -> Inj.mouseBtn(1, true)
                1004 -> Inj.mouseBtn(2, true)
                1005 -> Inj.mouseBtn(4, true)
                1006 -> Inj.mouseMove(0, 0, 1)
                1007 -> Inj.mouseMove(0, 0, -1)
            }
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f
            when (k.code) {
                1003 -> Inj.mouseBtn(1, false)
                1004 -> Inj.mouseBtn(2, false)
                1005 -> Inj.mouseBtn(4, false)
            }
        }
        return true
    }

    /** 1 dedo move o cursor · toque rápido = clique · 2 dedos = botão direito segurado (girar câmera). */
    private fun mouseTouch() = object : View.OnTouchListener {
        var lx = 0f; var ly = 0f; var t0 = 0L; var dist = 0f; var right = false; var skip = false; var ax = 0f; var ay = 0f
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; t0 = e.eventTime; dist = 0f; skip = false }
                MotionEvent.ACTION_MOVE -> {
                    if (skip) { lx = e.rawX; ly = e.rawY; skip = false } else {
                        val s = prefs.getInt("msens", 150) / 100f
                        val dx = e.rawX - lx; val dy = e.rawY - ly; lx = e.rawX; ly = e.rawY
                        dist += abs(dx) + abs(dy)
                        ax += dx * s; ay += dy * s
                        val mx = ax.toInt(); val my = ay.toInt(); ax -= mx; ay -= my
                        if (mx != 0 || my != 0) Inj.mouseMove(mx, my)
                    }
                }
                MotionEvent.ACTION_POINTER_DOWN -> { if (!right) { right = true; Inj.mouseBtn(2, true) }; skip = true }
                MotionEvent.ACTION_POINTER_UP -> { if (right && e.pointerCount <= 2) { right = false; Inj.mouseBtn(2, false) }; skip = true }
                MotionEvent.ACTION_UP -> {
                    if (right) { right = false; Inj.mouseBtn(2, false) }
                    else if (dist < 20 && e.eventTime - t0 < 300) { Inj.mouseBtn(1, true); Inj.mouseBtn(1, false) }
                }
                MotionEvent.ACTION_CANCEL -> if (right) { right = false; Inj.mouseBtn(2, false) }
            }
            return true
        }
    }

    private fun needMouse(): Boolean {
        if (!Inj.mouseOn) Toast.makeText(this, "Ative \"Teclado + mouse\" (USB ou Bluetooth) no app e toque em Iniciar", Toast.LENGTH_LONG).show()
        return Inj.mouseOn
    }

    /** Mouse livre: a tela inteira vira área de mouse (a janela fica por baixo das teclas). */
    private fun toggleFree() {
        val f = free ?: return
        freeOn = !freeOn
        if (freeOn && !needMouse()) { freeOn = false; return }
        f.visibility = if (freeOn) View.VISIBLE else View.GONE
        fp.flags = if (freeOn) fp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else fp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(f, fp)
        keys.forEach { paint(it) }
    }

    /** Touchpad: janela pequena, movível (≡) e redimensionável (⤡). */
    private fun toggleTouchpad() {
        if (tpad != null) { rm(tpad); tpad = null; keys.forEach { paint(it) }; return }
        if (!needMouse()) return
        val p = lp(prefs.getInt("tpw", 260.dp()), prefs.getInt("tph", 170.dp()))
        p.x = prefs.getInt("tpx", 24.dp()); p.y = prefs.getInt("tpy", 140.dp())
        val saveP = { prefs.edit().putInt("tpx", p.x).putInt("tpy", p.y).putInt("tpw", p.width).putInt("tph", p.height).apply() }
        val area = TextView(this).apply {
            text = "TOUCHPAD"; setTextColor(0x55FFFFFF); gravity = Gravity.CENTER; textSize = 12f
            background = GradientDrawable().apply { cornerRadius = 12 * d; setColor(0x55000000); setStroke(1.dp(), 0x66FFFFFF) }
            setOnTouchListener(mouseTouch())
        }
        val move = pill("≡") {}.apply {
            setOnTouchListener(drag({ ix = p.x; iy = p.y },
                { dx, dy -> p.x = ix + dx.toInt(); p.y = iy + dy.toInt(); wm.updateViewLayout(tpad, p) }, end = { saveP() }))
        }
        val size = pill("⤡") {}.apply {
            setOnTouchListener(drag({ ix = p.width; iy = p.height },
                { dx, dy -> p.width = (ix + dx).toInt().coerceAtLeast(120.dp()); p.height = (iy + dy).toInt().coerceAtLeast(90.dp()); wm.updateViewLayout(tpad, p) },
                end = { saveP() }))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(4.dp(), 2.dp(), 4.dp(), 4.dp())
            background = GradientDrawable().apply { cornerRadius = 16 * d; setColor(0xCC111827.toInt()) }
            addView(row(move, size, pill("✕") { toggleTouchpad() }))
            addView(area, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        tpad = box; wm.addView(box, p); keys.forEach { paint(it) }
    }

    // ---------- gamepad virtual ----------
    private fun sym(k: K) = if (k.mode in 1 until Pad.short.size) " " + Pad.short[k.mode] else ""

    private fun padKey(k: K, v: View, e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { v.alpha = .7f; v.scaleX = .92f; v.scaleY = .92f; Pad.set(k.mode, true) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f; Pad.set(k.mode, false) }
        }
        return true
    }

    private fun pickFunction() {
        val k = sel ?: run { Toast.makeText(this, "Toque numa tecla para selecioná-la", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_Alert))
            .setTitle("Função da tecla ${k.label}")
            .setItems(Pad.names.toTypedArray()) { _, i -> k.mode = i; views[k]?.text = k.label + sym(k); save() }
            .create().apply { window!!.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); show() }
    }

    private fun presetGame() {
        val m = mapOf("W" to 1, "A" to 2, "S" to 3, "D" to 4, "UP" to 5, "LEFT" to 6, "DOWN" to 7, "RIGHT" to 8,
            "SPACE" to 13, "F" to 14, "E" to 15, "Q" to 16)
        keys.forEach { k -> m[k.label]?.let { k.mode = it; views[k]?.text = k.label + sym(k) } }
        save()
        Toast.makeText(this, "WASD = analógico, setas = câmera, SPACE = pular", Toast.LENGTH_LONG).show()
    }

    // ---------- barra do editor ----------
    private fun pill(t: String, c: Int = 0xFF334155.toInt(), f: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setPadding(8.dp(), 9.dp(), 8.dp(), 9.dp())
        background = GradientDrawable().apply { cornerRadius = 20 * d; setColor(c) }
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(3.dp(), 3.dp(), 3.dp(), 3.dp()) }
        setOnClickListener { f() }
    }

    private fun seek(t: String, min: Int, max: Int, cur: Int, on: (Int) -> Unit): View {
        val lbl = TextView(this).apply { setTextColor(0xFFCBD5E1.toInt()); textSize = 11f; text = "$t: $cur" }
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = cur - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { lbl.text = "$t: ${min + v}"; if (u) on(min + v) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { save() }
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; addView(lbl); addView(sb)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(4.dp(), 2.dp(), 4.dp(), 2.dp()) }
        }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply { v.forEach { addView(it) } }

    private fun buildToolbar() {
        tbp = lp(minOf(320.dp(), resources.displayMetrics.widthPixels - 16.dp()), -2).apply { x = 8.dp(); y = 48.dp() }
        val grip = TextView(this).apply {
            text = "≡  Editor do teclado"; setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            setPadding(8.dp(), 8.dp(), 8.dp(), 8.dp())
            setOnTouchListener(drag({ ix = tbp.x; iy = tbp.y }, { dx, dy -> tbp.x = ix + dx.toInt(); tbp.y = iy + dy.toInt(); wm.updateViewLayout(tb, tbp) }))
        }
        val moveAll = pill("✥ Mover tudo") {}.apply {
            setOnTouchListener(drag({ ix = ox; iy = oy }, { dx, dy -> ox = ix + dx.toInt(); oy = iy + dy.toInt(); relayout() }))
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(10.dp(), 6.dp(), 10.dp(), 8.dp())
            background = GradientDrawable().apply { cornerRadius = 18 * d; setColor(0xF2111827.toInt()); setStroke(1.dp(), 0x886366F1.toInt()) }
            addView(LinearLayout(this@OverlayService).apply {
                addView(grip, LinearLayout.LayoutParams(0, -2, 2f)); addView(pill("Concluir", PRIMARY) { setEdit(false) })
            })
            addView(row(pill("+ Tecla") { addKey() }, pill("Apagar", 0xFF7F1D1D.toInt()) {
                sel?.let { rm(views.remove(it)); lps.remove(it); keys -= it; sel = null; save() }
            }, pill("Cor") { kc = (kc + 1) % PALETTE.size; keys.forEach { paint(it) }; save() }, moveAll))
            addView(row(pill("Larg −") { resize(-4f, 0f) }, pill("Larg +") { resize(4f, 0f) },
                pill("Alt −") { resize(0f, -4f) }, pill("Alt +") { resize(0f, 4f) }))
            addView(row(pill("Função ⟳") { pickFunction() }, pill("Preset jogo") { presetGame() }))
            addView(row(seek("Largura teclado %", 30, 300, sw) { sw = it; relayout() },
                seek("Altura teclado %", 30, 300, sh) { sh = it; relayout() }))
            addView(row(seek("Opacidade %", 15, 100, ka) { ka = it; keys.forEach { k -> paint(k) } },
                seek("Arredondado", 0, 30, kr) { kr = it; keys.forEach { k -> paint(k) } }))
        }
        tb = card
        wm.addView(card, tbp)
    }

    private fun resize(dw: Float, dh: Float) {
        sel?.let { it.w = (it.w + dw).coerceAtLeast(16f); it.h = (it.h + dh).coerceAtLeast(16f); layoutKey(it); save() }
    }

    private fun addKey() {
        val names = Keys.map.keys.toTypedArray()
        AlertDialog.Builder(ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_Alert))
            .setTitle("Adicionar tecla")
            .setItems(names) { _, i ->
                val cd = Keys.map[names[i]]!!; val big = cd == 1000
                val k = K(names[i], cd, 8f, 8f, if (big) 90f else 44f, if (big) 90f else 40f)
                keys += k; addKeyWindow(k); sel = k; keys.forEach { paint(it) }; save()
            }
            .create().apply { window!!.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); show() }
    }
}
