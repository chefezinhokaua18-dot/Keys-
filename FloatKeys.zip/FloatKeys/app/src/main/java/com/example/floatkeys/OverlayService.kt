package com.example.floatkeys

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

class K(var label: String, var code: Int, var x: Int, var y: Int, var w: Int, var h: Int) // medidas em dp

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var canvas: FrameLayout
    private lateinit var editRow: View
    private lateinit var hr: View   // alça lateral (largura)
    private lateinit var hb: View   // alça inferior (altura)
    private lateinit var pp: WindowManager.LayoutParams
    private lateinit var bp: WindowManager.LayoutParams
    private var bubble: TextView? = null
    private val keys = mutableListOf<K>()
    private val views = HashMap<K, TextView>()
    private val active = HashSet<K>()
    private var sel: K? = null
    private var edit = false
    private var shown = false
    private var pw = 340; private var ph = 270
    private var ox = 0; private var oy = 0
    private val d get() = resources.displayMetrics.density
    private fun Int.dp() = (this * d).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (bubble == null) init() else { wm.removeView(bubble); makeBubble() }
        return START_STICKY
    }

    override fun onDestroy() {
        if (shown) wm.removeView(root)
        bubble?.let { wm.removeView(it) }
        super.onDestroy()
    }

    private fun init() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("kb", MODE_PRIVATE)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("kb", "Teclado flutuante", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "kb").setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Teclado flutuante ativo").build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        load(); buildPanel(); makeBubble()
    }

    // ---------- persistência ----------
    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }

    private fun load() {
        pp = lp(0, 0); bp = lp(-2, -2)
        pp.x = 20.dp(); pp.y = 120.dp(); bp.x = 0; bp.y = 300.dp()
        val s = prefs.getString("layout", null)
        if (s == null) { defaults(); return }
        val o = JSONObject(s)
        pw = o.getInt("w"); ph = o.getInt("h"); pp.x = o.getInt("x"); pp.y = o.getInt("y"); bp.x = o.getInt("bx"); bp.y = o.getInt("by")
        val a = o.getJSONArray("keys")
        for (i in 0 until a.length()) a.getJSONObject(i).let {
            keys += K(it.getString("l"), it.getInt("c"), it.getInt("x"), it.getInt("y"), it.getInt("w"), it.getInt("h"))
        }
    }

    private fun save() {
        val ks = JSONArray()
        keys.forEach { ks.put(JSONObject().put("l", it.label).put("c", it.code).put("x", it.x).put("y", it.y).put("w", it.w).put("h", it.h)) }
        prefs.edit().putString("layout", JSONObject().put("w", pw).put("h", ph).put("x", pp.x).put("y", pp.y)
            .put("bx", bp.x).put("by", bp.y).put("keys", ks).toString()).apply()
    }

    private fun defaults() {
        listOf("ESC F1 F2 F3 F4 F5 F6", "TAB Q W E R T Y", "CAPS A S D F G ENTER", "SHIFT Z X C V B BKSP", "CTRL ALT SPACE LEFT UP DOWN RIGHT")
            .forEachIndexed { r, row -> row.split(" ").forEachIndexed { c, n -> keys += K(n, Keys.map[n]!!, 4 + c * 48, 4 + r * 44, 44, 40) } }
    }

    // ---------- UI ----------
    private fun tv(t: String, onClick: (() -> Unit)? = null) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); gravity = Gravity.CENTER; textSize = 12f
        setPadding(10.dp(), 6.dp(), 10.dp(), 6.dp())
        onClick?.let { setOnClickListener { _ -> it() } }
    }

    private fun drag(start: () -> Unit, move: (Float, Float) -> Unit, tap: () -> Unit = {}) = object : View.OnTouchListener {
        var sx = 0f; var sy = 0f; var moved = false
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; moved = false; start() }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) + abs(dy) > 12) moved = true
                    if (moved) move(dx, dy)
                }
                MotionEvent.ACTION_UP -> if (moved) save() else tap()
            }
            return true
        }
    }

    private fun makeBubble() {
        bubble = tv("⌨").apply {
            textSize = 22f; alpha = prefs.getInt("balpha", 90) / 100f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF263238.toInt()) }
            setOnTouchListener(drag({ ox = bp.x; oy = bp.y },
                { dx, dy -> bp.x = ox + dx.toInt(); bp.y = oy + dy.toInt(); wm.updateViewLayout(this, bp) }, { toggle() }))
        }
        bp.width = prefs.getInt("bsize", 52).dp(); bp.height = bp.width
        wm.addView(bubble, bp)
    }

    private fun toggle() {
        if (shown) {
            active.forEach { if (it.code != KeyEvent.KEYCODE_CAPS_LOCK) Inj.send(it.code, false, 0) }
            active.clear(); wm.removeView(root)
        } else {
            if (!Inj.ready()) Toast.makeText(this, "Shizuku inativo ou sem permissão", Toast.LENGTH_LONG).show()
            wm.addView(root, pp)
        }
        shown = !shown
    }

    private fun buildPanel() {
        pp.width = pw.dp(); pp.height = ph.dp()
        root = FrameLayout(this).apply { background = GradientDrawable().apply { cornerRadius = 12 * d; setColor(0xE6101820.toInt()) } }
        val grip = tv("≡  mover").apply {
            setOnTouchListener(drag({ ox = pp.x; oy = pp.y }, { dx, dy -> pp.x = ox + dx.toInt(); pp.y = oy + dy.toInt(); wm.updateViewLayout(root, pp) }))
        }
        val bar = LinearLayout(this).apply {
            addView(grip, LinearLayout.LayoutParams(0, -2, 1f))
            addView(tv("✎") { setEdit(!edit) }); addView(tv("✕") { toggle() })
        }
        editRow = HorizontalScrollView(this).apply {
            visibility = View.GONE
            addView(LinearLayout(this@OverlayService).apply {
                addView(tv("+ Tecla") { addKey() })
                addView(tv("L+") { resize(4, 0) }); addView(tv("L−") { resize(-4, 0) })
                addView(tv("A+") { resize(0, 4) }); addView(tv("A−") { resize(0, -4) })
                addView(tv("Apagar") { sel?.let { keys -= it; sel = null; render(); save() } })
            })
        }
        canvas = FrameLayout(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bar); addView(editRow); addView(canvas, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        hr = View(this).apply {
            setBackgroundColor(0x99FFC107.toInt()); visibility = View.GONE
            setOnTouchListener(drag({ ox = pw }, { dx, _ -> pw = (ox + dx / d).toInt().coerceIn(120, 1500); pp.width = pw.dp(); wm.updateViewLayout(root, pp) }))
        }
        hb = View(this).apply {
            setBackgroundColor(0x99FFC107.toInt()); visibility = View.GONE
            setOnTouchListener(drag({ oy = ph }, { _, dy -> ph = (oy + dy / d).toInt().coerceIn(100, 1500); pp.height = ph.dp(); wm.updateViewLayout(root, pp) }))
        }
        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        root.addView(hr, FrameLayout.LayoutParams(16.dp(), -1, Gravity.END))
        root.addView(hb, FrameLayout.LayoutParams(-1, 16.dp(), Gravity.BOTTOM))
        render()
    }

    private fun setEdit(on: Boolean) {
        edit = on; sel = null
        val v = if (on) View.VISIBLE else View.GONE
        editRow.visibility = v; hr.visibility = v; hb.visibility = v
        keys.forEach { paint(it) }
        if (!on) save()
    }

    private fun snap(f: Float) = (Math.round(f / 4f) * 4).coerceAtLeast(0)

    private fun place(k: K) {
        views[k]?.layoutParams = FrameLayout.LayoutParams(k.w.dp(), k.h.dp()).apply { leftMargin = k.x.dp(); topMargin = k.y.dp() }
    }

    private fun paint(k: K) {
        views[k]?.background = GradientDrawable().apply {
            cornerRadius = 8 * d
            setColor(when { edit && k === sel -> 0xFFF9A825.toInt(); k in active -> 0xFF1E88E5.toInt(); else -> 0xFF37474F.toInt() })
        }
    }

    private fun render() {
        canvas.removeAllViews(); views.clear()
        keys.forEach { k ->
            val v = tv(k.label); views[k] = v
            place(k); canvas.addView(v); paint(k)
            val ed = drag({ sel = k; ox = k.x; oy = k.y; keys.forEach { paint(it) } },
                { dx, dy -> k.x = snap(ox + dx / d); k.y = snap(oy + dy / d); place(k) })
            v.setOnTouchListener { _, e -> if (edit) ed.onTouch(v, e) else play(k, v, e) }
        }
    }

    private fun resize(dw: Int, dh: Int) {
        sel?.let { it.w = (it.w + dw).coerceAtLeast(20); it.h = (it.h + dh).coerceAtLeast(20); place(it); save() }
    }

    private fun addKey() {
        val names = Keys.map.keys.toTypedArray()
        AlertDialog.Builder(ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_Alert))
            .setTitle("Adicionar tecla")
            .setItems(names) { _, i -> keys += K(names[i], Keys.map[names[i]]!!, 8, 8, 44, 40); render(); save() }
            .create().apply { window!!.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); show() }
    }

    // ---------- ação das teclas ----------
    private fun meta() = active.fold(0) { m, k -> m or Keys.meta(k.code) }

    private fun play(k: K, v: View, e: MotionEvent): Boolean {
        val mod = Keys.meta(k.code) != 0
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                v.alpha = .6f; v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                if (!mod) Inj.send(k.code, true, meta()) else {
                    // SHIFT/CTRL/ALT/WIN: toque liga (mantém pressionada), toque de novo solta. CAPS: clique + estado visual.
                    val on = if (k in active) { active -= k; false } else { active += k; true }
                    if (k.code == KeyEvent.KEYCODE_CAPS_LOCK) { Inj.send(k.code, true, 0); Inj.send(k.code, false, 0) }
                    else Inj.send(k.code, on, meta())
                    paint(k)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.alpha = 1f; if (!mod) Inj.send(k.code, false, meta()) }
        }
        return true
    }
}
