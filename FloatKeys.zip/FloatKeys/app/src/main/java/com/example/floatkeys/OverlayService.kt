package com.example.floatkeys

import android.app.Service
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var rootContainer: FrameLayout
    private lateinit var keyboardPanel: LinearLayout
    private var panelParams: WindowManager.LayoutParams? = null

    private var opacityValue = 0.85f
    private var keyScale = 1.0f
    private var editMode = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        setupOverlay()
    }

    private fun setupOverlay() {
        rootContainer = FrameLayout(this)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // NOTA: FLAG_NOT_FOCUSABLE evita roubar foco de toques fora do painel
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        panelParams = params

        keyboardPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            background = createPanelBackground()
        }

        val controlsBar = createControlsBar()
        val keysRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val keys = listOf(
            "W" to KeyEvent.KEYCODE_W,
            "A" to KeyEvent.KEYCODE_A,
            "S" to KeyEvent.KEYCODE_S,
            "D" to KeyEvent.KEYCODE_D,
            "SPACE" to KeyEvent.KEYCODE_SPACE
        )

        for ((label, code) in keys) {
            keysRow.addView(createDraggableKey(label, code))
        }

        keyboardPanel.addView(controlsBar)
        keyboardPanel.addView(keysRow)

        val panelLp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).apply {
            bottomMargin = 48
        }

        rootContainer.addView(keyboardPanel, panelLp)
        applyVisualState()
        windowManager.addView(rootContainer, params)
    }

    private fun createPanelBackground(): GradientDrawable {
        return GradientDrawable().apply {
            cornerRadius = 32f
            setColor(Color.argb((opacityValue * 255).toInt(), 24, 28, 36))
            setStroke(2, Color.argb(90, 255, 255, 255))
        }
    }

    private fun createControlsBar(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 0, 8, 16)

            val modeBtn = Button(this@OverlayService).apply {
                text = if (editMode) "Modo: Mover" else "Modo: Jogar"
                textSize = 12f
                setOnClickListener {
                    editMode = !editMode
                    text = if (editMode) "Modo: Mover" else "Modo: Jogar"
                }
            }

            val alphaLabel = TextView(this@OverlayService).apply {
                text = " Opacidade "
                setTextColor(Color.WHITE)
                textSize = 12f
            }

            val alphaSeek = SeekBar(this@OverlayService).apply {
                max = 100
                progress = (opacityValue * 100).toInt()
                layoutParams = LinearLayout.LayoutParams(220, LinearLayout.LayoutParams.WRAP_CONTENT)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                        opacityValue = (p.coerceAtLeast(15)) / 100f
                        applyVisualState()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }

            val sizeSeek = SeekBar(this@OverlayService).apply {
                max = 140
                min = 60
                progress = (keyScale * 100).toInt()
                layoutParams = LinearLayout.LayoutParams(220, LinearLayout.LayoutParams.WRAP_CONTENT)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                        keyScale = p / 100f
                        applyVisualState()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }

            addView(modeBtn)
            addView(alphaLabel)
            addView(alphaSeek)
            addView(sizeSeek)
        }
    }

    private fun createDraggableKey(label: String, keyCode: Int): Button {
        val baseWidth = if (keyCode == KeyEvent.KEYCODE_SPACE) 220 else 120
        val baseHeight = 120

        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 24f
                setColor(Color.argb(210, 48, 56, 72))
                setStroke(2, Color.argb(120, 130, 170, 255))
            }
            layoutParams = LinearLayout.LayoutParams(baseWidth, baseHeight).apply {
                setMargins(10, 6, 10, 6)
            }

            var detachedToRoot = false
            var dX = 0f
            var dY = 0f

            setOnTouchListener { v, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        dX = event.rawX - v.x
                        dY = event.rawY - v.y
                        if (!editMode) {
                            Inj.sendKeyState(keyCode, true)
                        }
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (editMode) {
                            if (!detachedToRoot && v.parent is LinearLayout) {
                                val parentRow = v.parent as LinearLayout
                                val startX = event.rawX - dX
                                val startY = event.rawY - dY
                                parentRow.removeView(v)
                                val flp = FrameLayout.LayoutParams(v.width, v.height)
                                rootContainer.addView(v, flp)
                                v.x = startX
                                v.y = startY
                                detachedToRoot = true
                            }
                            if (detachedToRoot) {
                                v.x = event.rawX - dX
                                v.y = event.rawY - dY
                            }
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (!editMode) {
                            Inj.sendKeyState(keyCode, false)
                        }
                        v.performClick()
                        true
                    }
                    else -> false
                }
            }
        }
    }

    private fun applyVisualState() {
        keyboardPanel.background = createPanelBackground()
        keyboardPanel.alpha = opacityValue
        for (i in 0 until keyboardPanel.childCount) {
            val child = keyboardPanel.getChildAt(i)
            if (child is LinearLayout) {
                for (j in 0 until child.childCount) {
                    val keyView = child.getChildAt(j)
                    keyView.scaleX = keyScale
                    keyView.scaleY = keyScale
                }
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val lp = keyboardPanel.layoutParams as? FrameLayout.LayoutParams ?: return
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            lp.bottomMargin = 24
        } else {
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            lp.bottomMargin = 64
        }
        keyboardPanel.layoutParams = lp
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::rootContainer.isInitialized && rootContainer.isAttachedToWindow) {
            windowManager.removeView(rootContainer)
        }
    }
}
