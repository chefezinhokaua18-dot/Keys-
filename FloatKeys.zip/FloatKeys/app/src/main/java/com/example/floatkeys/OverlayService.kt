package com.example.floatkeys

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var keyboardPanel: LinearLayout
    private lateinit var panelParams: WindowManager.LayoutParams

    private val floatingKeyViews = mutableListOf<Pair<View, WindowManager.LayoutParams>>()

    private var opacityValue = 0.85f
    private var keyScale = 1.0f
    private var editMode = true
    private var minimized = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()

        val p = getSharedPreferences("kb", MODE_PRIVATE)
        opacityValue = (p.getInt("balpha", 90).coerceIn(20, 100)) / 100f
        keyScale = (p.getInt("bsize", 52).coerceIn(32, 96)) / 52f

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        setupKeyboardWindow()
    }

    private fun startAsForeground() {
        val channelId = "floatkeys_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                channelId,
                "FloatKeys Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(ch)
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        val notif = builder
            .setContentTitle("FloatKeys ativo")
            .setContentText("Toque livre na tela habilitado")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(101, notif)
    }

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun passThroughFlags(): Int {
        return WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    }

    private fun setupKeyboardWindow() {
        keyboardPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            background = createPanelBackground()
        }

        keyboardPanel.addView(createTopBar())
        keyboardPanel.addView(createFullPcKeyboard())

        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            passThroughFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 24
        }

        applyVisualState()
        windowManager.addView(keyboardPanel, panelParams)
    }

    private fun createPanelBackground(): GradientDrawable {
        return GradientDrawable().apply {
            cornerRadius = 28f
            setColor(Color.argb((opacityValue * 255).toInt(), 18, 22, 30))
            setStroke(2, Color.argb(110, 120, 150, 210))
        }
    }

    private fun createTopBar(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 0, 4, 10)

            fun smallBtn(label: String, onClick: (Button) -> Unit): Button {
                return Button(this@OverlayService).apply {
                    text = label
                    textSize = 11f
                    isAllCaps = false
                    setTextColor(Color.WHITE)
                    minHeight = 0
                    minimumHeight = 0
                    setPadding(18, 8, 18, 8)
                    background = GradientDrawable().apply {
                        cornerRadius = 16f
                        setColor(Color.parseColor("#2563EB"))
                    }
                    setOnClickListener { onClick(this) }
                }
            }

            val modeBtn = smallBtn(if (editMode) "Mover: ON" else "Jogar: ON") { btn ->
                editMode = !editMode
                btn.text = if (editMode) "Mover: ON" else "Jogar: ON"
                (btn.background as? GradientDrawable)?.setColor(
                    Color.parseColor(if (editMode) "#2563EB" else "#16A34A")
                )
            }

            val hideBtn = smallBtn("Min") {
                minimized = !minimized
                for (i in 1 until keyboardPanel.childCount) {
                    keyboardPanel.getChildAt(i).visibility =
                        if (minimized) View.GONE else View.VISIBLE
                }
                windowManager.updateViewLayout(keyboardPanel, panelParams)
            }

            val alphaLabel = TextView(this@OverlayService).apply {
                text = " Opac "
                setTextColor(Color.WHITE)
                textSize = 11f
            }

            val alphaSeek = SeekBar(this@OverlayService).apply {
                max = 100
                progress = (opacityValue * 100).toInt()
                layoutParams = LinearLayout.LayoutParams(150, LinearLayout.LayoutParams.WRAP_CONTENT)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                        opacityValue = (p.coerceAtLeast(15)) / 100f
                        applyVisualState()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }

            val sizeLabel = TextView(this@OverlayService).apply {
                text = " Tam "
                setTextColor(Color.WHITE)
                textSize = 11f
            }

            val sizeSeek = SeekBar(this@OverlayService).apply {
                max = 140
                min = 60
                progress = (keyScale * 100).toInt()
                layoutParams = LinearLayout.LayoutParams(150, LinearLayout.LayoutParams.WRAP_CONTENT)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                        keyScale = p / 100f
                        applyVisualState()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }

            addView(modeBtn)
            addView(spaceH(8))
            addView(hideBtn)
            addView(alphaLabel)
            addView(alphaSeek)
            addView(sizeLabel)
            addView(sizeSeek)
        }
    }

    private fun spaceH(dp: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams((dp * resources.displayMetrics.density).toInt(), 1)
    }

    private fun createFullPcKeyboard(): HorizontalScrollView {
        val hScroll = HorizontalScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_ALWAYS
        }

        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val rows: List<List<Pair<String, Int>>> = listOf(
            listOf(
                "ESC" to KeyEvent.KEYCODE_ESCAPE,
                "1" to KeyEvent.KEYCODE_1,
                "2" to KeyEvent.KEYCODE_2,
                "3" to KeyEvent.KEYCODE_3,
                "4" to KeyEvent.KEYCODE_4,
                "5" to KeyEvent.KEYCODE_5,
                "6" to KeyEvent.KEYCODE_6,
                "7" to KeyEvent.KEYCODE_7,
                "8" to KeyEvent.KEYCODE_8,
                "9" to KeyEvent.KEYCODE_9,
                "0" to KeyEvent.KEYCODE_0,
                "BKSP" to KeyEvent.KEYCODE_DEL
            ),
            listOf(
                "TAB" to KeyEvent.KEYCODE_TAB,
                "Q" to KeyEvent.KEYCODE_Q,
                "W" to KeyEvent.KEYCODE_W,
                "E" to KeyEvent.KEYCODE_E,
                "R" to KeyEvent.KEYCODE_R,
                "T" to KeyEvent.KEYCODE_T,
                "Y" to KeyEvent.KEYCODE_Y,
                "U" to KeyEvent.KEYCODE_U,
                "I" to KeyEvent.KEYCODE_I,
                "O" to KeyEvent.KEYCODE_O,
                "P" to KeyEvent.KEYCODE_P
            ),
            listOf(
                "CTRL" to KeyEvent.KEYCODE_CTRL_LEFT,
                "A" to KeyEvent.KEYCODE_A,
                "S" to KeyEvent.KEYCODE_S,
                "D" to KeyEvent.KEYCODE_D,
                "F" to KeyEvent.KEYCODE_F,
                "G" to KeyEvent.KEYCODE_G,
                "H" to KeyEvent.KEYCODE_H,
                "J" to KeyEvent.KEYCODE_J,
                "K" to KeyEvent.KEYCODE_K,
                "L" to KeyEvent.KEYCODE_L,
                "ENTER" to KeyEvent.KEYCODE_ENTER
            ),
            listOf(
                "SHIFT" to KeyEvent.KEYCODE_SHIFT_LEFT,
                "Z" to KeyEvent.KEYCODE_Z,
                "X" to KeyEvent.KEYCODE_X,
                "C" to KeyEvent.KEYCODE_C,
                "V" to KeyEvent.KEYCODE_V,
                "B" to KeyEvent.KEYCODE_B,
                "N" to KeyEvent.KEYCODE_N,
                "M" to KeyEvent.KEYCODE_M,
                "←" to KeyEvent.KEYCODE_DPAD_LEFT,
                "↑" to KeyEvent.KEYCODE_DPAD_UP,
                "↓" to KeyEvent.KEYCODE_DPAD_DOWN,
                "→" to KeyEvent.KEYCODE_DPAD_RIGHT
            ),
            listOf(
                "ALT" to KeyEvent.KEYCODE_ALT_LEFT,
                "SPACE" to KeyEvent.KEYCODE_SPACE
            )
        )

        for (rowKeys in rows) {
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            for ((label, code) in rowKeys) {
                rowLayout.addView(createKeyButton(label, code, floatingWindow = false))
            }
            grid.addView(rowLayout)
        }

        hScroll.addView(grid)
        return hScroll
    }

    private fun createKeyButton(
        label: String,
        keyCode: Int,
        floatingWindow: Boolean,
        initialLp: WindowManager.LayoutParams? = null
    ): Button {
        val d = resources.displayMetrics.density
        val w = when (keyCode) {
            KeyEvent.KEYCODE_SPACE -> (180 * d).toInt()
            KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_CTRL_LEFT -> (64 * d).toInt()
            else -> (44 * d).toInt()
        }
        val h = (42 * d).toInt()

        return Button(this).apply {
            text = label
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            isAllCaps = false
            setTextColor(Color.WHITE)
            minWidth = 0
            minimumWidth = 0
            minHeight = 0
            minimumHeight = 0
            setPadding(4, 2, 4, 2)
            background = GradientDrawable().apply {
                cornerRadius = 12f
                setColor(Color.argb(225, 42, 50, 66))
                setStroke(1, Color.argb(120, 135, 170, 235))
            }
            layoutParams = if (floatingWindow) {
                ViewGroup.LayoutParams(w, h)
            } else {
                LinearLayout.LayoutParams(w, h).apply {
                    setMargins((3 * d).toInt(), (3 * d).toInt(), (3 * d).toInt(), (3 * d).toInt())
                }
            }

            var isFloating = floatingWindow
            var winParams = initialLp
            var startRawX = 0f
            var startRawY = 0f
            var startWinX = 0
            var startWinY = 0

            setOnTouchListener { v, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startRawX = event.rawX
                        startRawY = event.rawY
                        if (isFloating && winParams != null) {
                            startWinX = winParams!!.x
                            startWinY = winParams!!.y
                        }
                        if (!editMode) {
                            Inj.sendKeyState(keyCode, true)
                        }
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (editMode) {
                            val dx = (event.rawX - startRawX).toInt()
                            val dy = (event.rawY - startRawY).toInt()

                            if (!isFloating && v.parent is LinearLayout) {
                                val parentRow = v.parent as LinearLayout
                                val loc = IntArray(2)
                                v.getLocationOnScreen(loc)
                                parentRow.removeView(v)

                                val kp = WindowManager.LayoutParams(
                                    w,
                                    h,
                                    overlayType(),
                                    passThroughFlags(),
                                    PixelFormat.TRANSLUCENT
                                ).apply {
                                    gravity = Gravity.TOP or Gravity.START
                                    x = loc[0]
                                    y = loc[1]
                                }
                                winParams = kp
                                startWinX = kp.x
                                startWinY = kp.y
                                isFloating = true
                                floatingKeyViews.add(v to kp)
                                windowManager.addView(v, kp)
                            } else if (isFloating && winParams != null) {
                                winParams!!.x = startWinX + dx
                                winParams!!.y = startWinY + dy
                                windowManager.updateViewLayout(v, winParams)
                            }
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (!editMode) {
                            Inj.sendKeyState(keyCode, false)
                        }
                        v.performClick()
                        true
                    }
                    else -> false
                }
            }
        }
    }

    private fun applyVisualState() {
        keyboardPanel.background = createPanelBackground()
        keyboardPanel.alpha = opacityValue
        applyScaleRecursive(keyboardPanel)
        for ((keyView, _) in floatingKeyViews) {
            keyView.scaleX = keyScale
            keyView.scaleY = keyScale
            keyView.alpha = opacityValue
        }
        if (::panelParams.isInitialized && keyboardPanel.isAttachedToWindow) {
            windowManager.updateViewLayout(keyboardPanel, panelParams)
        }
    }

    private fun applyScaleRecursive(view: View) {
        if (view is Button && view.text.length <= 5 && view.text !in listOf("Mover: ON", "Jogar: ON", "Min")) {
            view.scaleX = keyScale
            view.scaleY = keyScale
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                applyScaleRecursive(view.getChildAt(i))
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::panelParams.isInitialized && keyboardPanel.isAttachedToWindow) {
            panelParams.y = if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) 12 else 28
            windowManager.updateViewLayout(keyboardPanel, panelParams)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        for ((keyView, _) in floatingKeyViews) {
            if (keyView.isAttachedToWindow) {
                windowManager.removeView(keyView)
            }
        }
        floatingKeyViews.clear()
        if (::keyboardPanel.isInitialized && keyboardPanel.isAttachedToWindow) {
            windowManager.removeView(keyboardPanel)
        }
    }
}
