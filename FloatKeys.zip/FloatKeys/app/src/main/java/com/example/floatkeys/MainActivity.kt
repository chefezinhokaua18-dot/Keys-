package com.example.floatkeys

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var st: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("kb", MODE_PRIVATE)
        val m = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(m, 3 * m, m, m) }
        st = TextView(this); col.addView(st)
        fun btn(t: String, f: () -> Unit) = col.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        fun seek(t: String, k: String, min: Int, max: Int, def: Int) {
            col.addView(TextView(this).apply { text = t })
            col.addView(SeekBar(this).apply {
                this.max = max - min; progress = p.getInt(k, def) - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {}
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) { p.edit().putInt(k, min + (s?.progress ?: 0)).apply() }
                })
            })
        }
        btn("1) Permitir sobreposição de tela") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2) Autorizar Shizuku") {
            if (Shizuku.pingBinder()) Shizuku.requestPermission(1)
            else Toast.makeText(this, "Abra o app Shizuku e inicie o serviço", Toast.LENGTH_LONG).show()
        }
        seek("Tamanho do atalho (dp)", "bsize", 32, 96, 52)
        seek("Opacidade do atalho (%)", "balpha", 20, 100, 90)
        btn("3) Iniciar / atualizar atalho") {
            if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java))
            else Toast.makeText(this, "Falta a permissão de sobreposição", Toast.LENGTH_LONG).show()
        }
        btn("Parar") { stopService(Intent(this, OverlayService::class.java)) }
        setContentView(col)
    }

    override fun onResume() {
        super.onResume()
        st.text = "Sobreposição: ${if (Settings.canDrawOverlays(this)) "OK" else "falta"}\n" +
            "Shizuku: ${if (Inj.ready()) "OK" else "inativo / sem permissão"}"
    }
}
