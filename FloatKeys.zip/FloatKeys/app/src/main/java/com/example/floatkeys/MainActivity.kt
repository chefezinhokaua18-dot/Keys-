package com.example.floatkeys

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var st: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("kb", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val pad = (18 * d).toInt()

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0D1117"))
            isFillViewport = true
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, (40 * d).toInt(), pad, pad)
        }

        val title = TextView(this).apply {
            text = "FloatKeys"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#F0F6FC"))
        }

        val subtitle = TextView(this).apply {
            text = "Configuração do atalho, Shizuku e sobreposição"
            textSize = 13f
            setTextColor(Color.parseColor("#8B949E"))
            setPadding(0, (4 * d).toInt(), 0, (16 * d).toInt())
        }

        st = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#E6EDF3"))
            setPadding((14 * d).toInt(), (12 * d).toInt(), (14 * d).toInt(), (12 * d).toInt())
            background = roundBg("#161B22", "#30363D", 12f * d)
        }

        fun space(dp: Int) = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = (dp * d).toInt() }

        fun btn(t: String, accent: String, f: () -> Unit) = Button(this).apply {
            text = t
            isAllCaps = false
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding((16 * d).toInt(), (13 * d).toInt(), (16 * d).toInt(), (13 * d).toInt())
            background = roundBg(accent, accent, 12f * d)
            setOnClickListener { f() }
        }.also { col.addView(it, space(10)) }

        fun seek(t: String, k: String, min: Int, max: Int, def: Int, unit: String) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((14 * d).toInt(), (12 * d).toInt(), (14 * d).toInt(), (12 * d).toInt())
                background = roundBg("#161B22", "#21262D", 12f * d)
            }
            val current = p.getInt(k, def).coerceIn(min, max)
            val label = TextView(this).apply {
                text = "$t: $current$unit"
                textSize = 13f
                setTextColor(Color.parseColor("#E6EDF3"))
            }
            val bar = SeekBar(this).apply {
                this.max = max - min
                progress = current - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                        label.text = "$t: ${min + v}$unit"
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {
                        val saved = min + (s?.progress ?: 0)
                        p.edit().putInt(k, saved).apply()
                        label.text = "$t: $saved$unit"
                    }
                })
            }
            card.addView(label)
            card.addView(bar, space(6))
            col.addView(card, space(12))
        }

        col.addView(title)
        col.addView(subtitle)
        col.addView(st)

        btn("1) Permitir sobreposição de tela", "#1F6FEB") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2) Autorizar Shizuku", "#238636") {
            if (Shizuku.pingBinder()) Shizuku.requestPermission(1)
            else Toast.makeText(this, "Abra o app Shizuku e inicie o serviço", Toast.LENGTH_LONG).show()
        }

        seek("Tamanho do atalho", "bsize", 32, 96, 52, " dp")
        seek("Opacidade do atalho", "balpha", 20, 100, 90, "%")

        btn("3) Iniciar / atualizar atalho", "#2EA043") {
            if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java))
            else Toast.makeText(this, "Falta a permissão de sobreposição", Toast.LENGTH_LONG).show()
        }
        btn("Parar", "#DA3633") {
            stopService(Intent(this, OverlayService::class.java))
        }

        val hint = TextView(this).apply {
            text = "Dica: o botão \"Iniciar / atualizar atalho\" reaplica os valores salvos no serviço."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#8B949E"))
        }
        col.addView(hint, space(16))

        scroll.addView(col)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        val overlayOk = Settings.canDrawOverlays(this)
        val shizukuOk = Inj.ready()
        st.text = "Sobreposição: ${if (overlayOk) "OK" else "falta"}\n" +
            "Shizuku: ${if (shizukuOk) "OK" else "inativo / sem permissão"}"
    }

    private fun roundBg(fillHex: String, strokeHex: String, radiusPx: Float): GradientDrawable {
        return GradientDrawable().apply {
            cornerRadius = radiusPx
            setColor(Color.parseColor(fillHex))
            setStroke((1.5f * resources.displayMetrics.density).toInt(), Color.parseColor(strokeHex))
        }
    }
}
