package com.example.floatkeys

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var tOv: TextView
    private lateinit var tSh: TextView
    private val d get() = resources.displayMetrics.density
    private fun Int.dp() = (this * d).toInt()
    private fun bg(c: Int, r: Int = 18) = GradientDrawable().apply { setColor(c); cornerRadius = r * d }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dark = 0xFF0B1020.toInt()
        window.statusBarColor = dark; window.navigationBarColor = dark
        val p = getSharedPreferences("kb", MODE_PRIVATE)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20.dp(), 48.dp(), 20.dp(), 28.dp()) }

        fun tx(t: String, size: Float, c: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        fun card(title: String): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(0xFF151B2E.toInt()); setPadding(16.dp(), 14.dp(), 16.dp(), 16.dp())
            col.addView(this, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 14.dp() })
            addView(tx(title, 12f, 0xFF94A3B8.toInt(), true))
        }
        fun btn(parent: LinearLayout, t: String, c: Int = 0xFF263148.toInt(), f: () -> Unit) =
            parent.addView(tx(t, 14f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER; setPadding(0, 14.dp(), 0, 14.dp()); background = bg(c, 14); setOnClickListener { f() }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8.dp() })
        fun seek(parent: LinearLayout, t: String, key: String, min: Int, max: Int, def: Int) {
            val cur = p.getInt(key, def)
            val lbl = tx("$t: $cur", 13f, 0xFFE2E8F0.toInt()).apply { setPadding(0, 12.dp(), 0, 0) }
            parent.addView(lbl)
            parent.addView(SeekBar(this).apply {
                this.max = max - min; progress = cur - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { lbl.text = "$t: ${min + v}" }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) { p.edit().putInt(key, min + (s?.progress ?: 0)).apply() }
                })
            })
        }

        col.addView(tx("FloatKeys", 32f, Color.WHITE, true))
        col.addView(tx("Teclado de PC flutuante com mapeamento livre", 14f, 0xFF94A3B8.toInt()))

        val st = card("STATUS")
        tOv = tx("", 15f, Color.WHITE).apply { setPadding(0, 10.dp(), 0, 0) }
        tSh = tx("", 15f, Color.WHITE).apply { setPadding(0, 6.dp(), 0, 0) }
        st.addView(tOv); st.addView(tSh)

        val cfg = card("PERMISSÕES")
        btn(cfg, "Permitir sobreposição de tela") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn(cfg, "Autorizar Shizuku") {
            if (Shizuku.pingBinder()) Shizuku.requestPermission(1)
            else Toast.makeText(this, "Abra o app Shizuku e inicie o serviço", Toast.LENGTH_LONG).show()
        }

        val at = card("ATALHO FLUTUANTE")
        seek(at, "Tamanho", "bsize", 32, 96, 52)
        seek(at, "Opacidade (%)", "balpha", 20, 100, 90)
        at.addView(Switch(this).apply {
            text = "Modo jogo (gamepad virtual)"; setTextColor(0xFFE2E8F0.toInt()); setPadding(0, 16.dp(), 0, 0)
            isChecked = p.getBoolean("game", false)
            setOnCheckedChangeListener { _, c -> p.edit().putBoolean("game", c).apply() }
        })

        val go = card("AÇÕES")
        btn(go, "▶  Iniciar / atualizar atalho", 0xFF6366F1.toInt()) {
            if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java))
            else Toast.makeText(this, "Falta a permissão de sobreposição", Toast.LENGTH_LONG).show()
        }
        btn(go, "✎  Abrir editor do teclado") {
            if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java).setAction("edit"))
            else Toast.makeText(this, "Falta a permissão de sobreposição", Toast.LENGTH_LONG).show()
        }
        btn(go, "Parar", 0xFF7F1D1D.toInt()) { stopService(Intent(this, OverlayService::class.java)) }

        col.addView(tx("Toque na bolinha ⌨ para mostrar/ocultar as teclas.\nSegure a bolinha para editar o layout.\nNo editor: Preset jogo mapeia WASD, setas e SPACE para um gamepad virtual (ligue o Modo jogo).", 12f, 0xFF64748B.toInt()).apply {
            setPadding(4.dp(), 16.dp(), 4.dp(), 0)
        })
        setContentView(ScrollView(this).apply { setBackgroundColor(dark); isFillViewport = true; addView(col) })
    }

    override fun onResume() {
        super.onResume()
        val ok = 0xFF34D399.toInt(); val bad = 0xFFF87171.toInt()
        val ov = Settings.canDrawOverlays(this); val sh = Inj.ready()
        tOv.text = (if (ov) "●  " else "○  ") + "Sobreposição de tela"; tOv.setTextColor(if (ov) ok else bad)
        tSh.text = (if (sh) "●  " else "○  ") + "Shizuku autorizado"; tSh.setTextColor(if (sh) ok else bad)
    }
}
