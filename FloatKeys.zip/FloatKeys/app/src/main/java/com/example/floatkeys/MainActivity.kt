package com.example.floatkeys

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var chOv: TextView
    private lateinit var chSh: TextView
    private val d get() = resources.displayMetrics.density
    private fun Int.dp() = (this * d).toInt()
    private fun bg(c: Int, r: Int = 20) = GradientDrawable().apply { setColor(c); cornerRadius = r * d }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dark = 0xFF0B1020.toInt(); val card = 0xFF151B2E.toInt(); val txt = 0xFFF1F5F9.toInt(); val sub = 0xFF94A3B8.toInt()
        window.statusBarColor = dark; window.navigationBarColor = dark
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 7)
        val p = getSharedPreferences("kb", MODE_PRIVATE)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18.dp(), 40.dp(), 18.dp(), 28.dp()) }

        fun tx(t: String, size: Float, c: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        fun lp(top: Int = 12) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = top.dp() }
        fun mk(t: String, c: Int, f: () -> Unit) = tx(t, 16f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; setPadding(10.dp(), 16.dp(), 10.dp(), 16.dp()); background = bg(c, 16); setOnClickListener { f() }
        }
        fun section(icon: String, title: String): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(card); setPadding(18.dp(), 16.dp(), 18.dp(), 18.dp())
            col.addView(this, lp(14))
            addView(tx("$icon  $title", 17f, txt, true))
        }
        fun seek(parent: LinearLayout, t: String, key: String, min: Int, max: Int, def: Int, unit: String) {
            val cur = p.getInt(key, def)
            val lbl = tx("$t: $cur$unit", 14f, txt).apply { setPadding(0, 14.dp(), 0, 4.dp()) }
            parent.addView(lbl)
            parent.addView(SeekBar(this).apply {
                this.max = max - min; progress = cur - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { lbl.text = "$t: ${min + v}$unit" }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) { p.edit().putInt(key, min + (s?.progress ?: 0)).apply() }
                })
            })
        }
        fun radio(parent: LinearLayout, key: String, base: Int, opts: List<String>, vals: List<Int>, def: Int) {
            val g = RadioGroup(this).apply { setPadding(0, 6.dp(), 0, 0) }
            opts.forEachIndexed { i, t ->
                g.addView(RadioButton(this).apply {
                    text = t; id = base + i; textSize = 15f; setTextColor(txt); setPadding(4.dp(), 10.dp(), 0, 10.dp())
                    isChecked = p.getInt(key, def) == vals[i]
                })
            }
            g.setOnCheckedChangeListener { _, id -> p.edit().putInt(key, vals[id - base]).apply() }
            parent.addView(g)
        }
        fun start(action: String?) {
            if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "Falta a permissão de sobreposição de tela", Toast.LENGTH_LONG).show(); return }
            startForegroundService(Intent(this, OverlayService::class.java).apply { if (action != null) setAction(action) })
        }
        fun mkChip() = tx("", 13f, Color.WHITE, true).apply { setPadding(14.dp(), 8.dp(), 14.dp(), 8.dp()) }

        col.addView(tx("⌨  FloatKeys", 30f, Color.WHITE, true))
        col.addView(tx("Teclado e mouse de PC flutuantes para jogos", 14f, sub).apply { setPadding(0, 2.dp(), 0, 14.dp()) })
        chOv = mkChip(); chSh = mkChip()
        col.addView(LinearLayout(this).apply {
            addView(chOv, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = 8.dp() }); addView(chSh)
        })

        col.addView(mk("▶  Iniciar painel flutuante", 0xFF6366F1.toInt()) { start(null) }, lp(16))
        col.addView(LinearLayout(this).apply {
            addView(mk("✎  Editar teclado", 0xFFD97706.toInt()) { start("edit") }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 6.dp() })
            addView(mk("■  Parar", 0xFFB91C1C.toInt()) { stopService(Intent(this@MainActivity, OverlayService::class.java)) },
                LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 6.dp() })
        }, lp(10))

        val s1 = section("🔐", "1 · Permissões")
        s1.addView(mk("Permitir sobreposição de tela", 0xFF263148.toInt()) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, lp(12))
        s1.addView(mk("Autorizar Shizuku", 0xFF263148.toInt()) {
            if (Shizuku.pingBinder()) Shizuku.requestPermission(1)
            else Toast.makeText(this, "Abra o app Shizuku e inicie o serviço", Toast.LENGTH_LONG).show()
        }, lp(10))

        val s2 = section("🔌", "2 · Tipo de dispositivo")
        s2.addView(tx("Como o Android enxerga o seu teclado", 13f, sub))
        radio(s2, "hidmode", 100, listOf("Normal (sem dispositivo HID)", "Teclado + mouse via USB (cabo/hub)", "Teclado + mouse via Bluetooth", "Gamepad virtual"),
            listOf(0, 1, 2, 3), 0)

        val s3 = section("🖱", "3 · Mouse")
        seek(s3, "Sensibilidade horizontal", "msx", 20, 500, 150, "%")
        seek(s3, "Sensibilidade vertical", "msy", 20, 500, 150, "%")
        s3.addView(tx("Botão segurado no modo Mouse jogo (arrastar = girar câmera)", 14f, txt).apply { setPadding(0, 18.dp(), 0, 0) })
        radio(s3, "gamebtn", 200, listOf("Botão direito (Roblox e similares)", "Botão esquerdo", "Só mover, sem segurar botão"), listOf(2, 1, 0), 0)

        val s4 = section("🔵", "4 · Bolinha")
        seek(s4, "Tamanho", "bsize", 32, 96, 52, " dp")
        seek(s4, "Opacidade", "balpha", 20, 100, 90, "%")

        val s5 = section("💡", "Como usar")
        s5.addView(tx("• Toque na bolinha: abre a roda de opções (teclado, editar, touchpad, mouse jogo, mouse livre, sumir, app, parar).\n" +
            "• Segure a bolinha: abre o editor do teclado.\n" +
            "• Puxe a barra de notificações: botões Teclado, Bolinha e Parar.\n" +
            "• Editor → + Tecla: JOY (analógico WASD), PAD, LIVRE, JOGO, cliques do mouse, rolagem e MACRO.\n" +
            "• Atirar e mirar juntos: no editor, toque no botão M-ESQ e deixe o Autoclique ligado.", 14f, sub).apply { setPadding(0, 10.dp(), 0, 0); setLineSpacing(0f, 1.15f) })

        setContentView(ScrollView(this).apply { setBackgroundColor(dark); isFillViewport = true; addView(col) })
    }

    private fun chip(v: TextView, t: String, ok: Boolean) {
        v.text = (if (ok) "✔  " else "✖  ") + t
        v.background = bg(if (ok) 0xFF065F46.toInt() else 0xFF7F1D1D.toInt(), 30)
    }

    override fun onResume() {
        super.onResume()
        chip(chOv, "Sobreposição", Settings.canDrawOverlays(this)); chip(chSh, "Shizuku", Inj.ready())
    }
}
