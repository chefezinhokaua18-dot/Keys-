package com.example.floatkeys;

interface IUhid {
    void destroy() = 16777114;
    boolean start() = 1;
    void report(in byte[] data) = 2;
    boolean startPad() = 3;
    void pad(in byte[] data) = 4;
}
