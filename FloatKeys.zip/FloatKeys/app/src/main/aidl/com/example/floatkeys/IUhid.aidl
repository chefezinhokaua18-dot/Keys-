package com.example.floatkeys;

interface IUhid {
    void destroy() = 16777114;
    boolean start(int bus) = 1;
    void report(in byte[] data) = 2;
    boolean startPad() = 3;
    void pad(in byte[] data) = 4;
    boolean startMouse(int bus) = 5;
    void mouse(in byte[] data) = 6;
}
